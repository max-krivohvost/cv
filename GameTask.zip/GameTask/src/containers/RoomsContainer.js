import React from 'react';
import { connect } from 'react-redux';

import RoomsList from '../components/RoomsList';

const RoomsContainer = ({rooms, user, selectRoomHandler, socket}) => (
  <div className="rooms-wrapper">
    <RoomsList
      rooms={rooms}
      currentRoomId={user ? user.currentRoomId : null}
      selectRoomHandler={selectRoomHandler}
      socket={socket}
    />
  </div>
);

const mapStateToProps = ({ user, rooms }) => ({
  user,
  rooms: rooms ? Object.values(rooms) : [],
});

export default connect(mapStateToProps)(RoomsContainer);
