import React, { Component } from "react";
import { connect } from "react-redux";
import axios from 'axios';

import {
  ROOM_SELECTED,
} from "../constants/ActionTypes";
import { setCurrentUser, updateRooms } from "../actions";
import history from "../history";

import RoomsContainer from "./RoomsContainer";
import CircleContainer from "./CircleContainer";

class GameContainer extends Component {
  joinRoom = roomId => {
    const { socket } = this.props;
    socket.emit(ROOM_SELECTED, roomId, this.joinRoomResponseHandler);
  };

  componentDidMount(){
   const { updateRooms } = this.props;
   this.getRooms().then((response) => {
      if(response.data){
        let rooms = {};
        response.data.forEach(element=>{
          rooms = this.createRoom(rooms, {
          id: element.roomid,
          name: element.name,
          color: element.color,
        });
      });
      updateRooms(rooms);
      }
    });
  }
  createRoom = (roomList, room) => {
    const newList = { ...roomList };
    newList[room.id] = room;
    return newList;
  }
  getRooms =() => {
    return axios.get('/api/v1/rooms');
  };
  
  joinRoomResponseHandler = response => {
    if (!response.result) {
      return;
    }
    this.props.setCurrentUser(response.user);
    history.push(`/rooms/${response.user.currentRoomId}`);
  };

  render() {
    return (
      <div className="game-container-wrapper">
        <div className="game-container">
          <div className="game-container--left">
            <RoomsContainer
              socket={this.props.socket}
              selectRoomHandler={this.joinRoom}
            />
          </div>
          <div className="game-container--right">
              <CircleContainer socket={this.props.socket} />
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = ({ user }) => {
  return {
    user
  };
};

export default connect(
  mapStateToProps,
  { setCurrentUser, updateRooms }
)(GameContainer);
