import React, { Component } from 'react';
import { connect } from 'react-redux';

import DynamicCircle from '../components/DynamicCircle';

const CircleContainer = ({ socket, color }) => (
  <div className="messages-wrapper">
    <DynamicCircle socket={socket} color={color} />
  </div>
);

const mapStateToProps = (state) => {
  const { rooms } = state;
  let color = 'red';
  if (rooms[state.user.currentRoomId]) {
    color = rooms[state.user.currentRoomId].color;
  }
  return { color };
};

export default connect(mapStateToProps)(CircleContainer);
