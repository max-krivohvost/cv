import React from 'react';
import { Provider } from 'react-redux';

import App from '../components/App';


const Root = ({ store, socket }) => (
  <Provider store={store}>
    <App socket={socket} />
  </Provider>
);

export default Root;
