import React from "react";
import { connect } from "react-redux";
import { Router, Route } from "react-router-dom";
import "./App.css";

import { USER_CONNECTED, USER_DISCONNECTED } from "../server/events";
import history from "../history";
import GameContainer from "../containers/GameContainer";
import { setCurrentUser } from "../actions";

class App extends React.Component {
  state = { socket: null };

  async componentDidMount() {
    await this.initSocket();
    this.state.socket.emit(
      USER_CONNECTED,
      this.userConnectedResponseHandler
    );
  }

  userConnectedResponseHandler = response => {
    if (!response.result) {
      this.setState({ loginError: response.error });
      return;
    }
    this.props.setCurrentUser(response.user);
    if (this.state.roomId !== response.user.currentRoomId) {
      history.push(`/rooms/${response.user.currentRoomId}`);
    }
    this.setState({ enterRoomId: "" });
  };

  componentWillUnmount() {
    const { socket } = this.state;

    if (this.props.user) {
      socket.emit(USER_DISCONNECTED, this.props.user.userId);
    }
  }

  initSocket = () => {
    const { socket } = this.props;
    socket.on("connect", () => {
      console.log("connected");
    });
    this.setState({ socket: socket });
  };

  render() {
    const { user } = this.props;
    const { socket } = this.state;

    return (
      <div className="App">
        <Router history={history}>
            <Route
              path={["/", "/rooms/:id"]}  
              render={props => (
                  user && <GameContainer {...props} socket={socket} user={user} />
                )
              }
            />
        </Router>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    user: state.user
  };
};

export default connect(mapStateToProps,{ setCurrentUser })(App);
