import React, { Component } from "react";
import {
    NEXT_COLOR
} from "../constants/ActionTypes";
import "./DynamicCircle.css";


class DynamicCircle extends Component {
    nextColor = () => {
      const { socket } = this.props;
      socket.emit(NEXT_COLOR);
    };

    render() {
      const { color } = this.props;
      return(<div style={{backgroundColor: color ? color : 'red' }} onClick={()=>{this.nextColor()}} className="dynamic-circle"></div>)
    }
};


export default DynamicCircle;