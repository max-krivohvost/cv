import React, { PureComponent } from "react";

import "./RoomsList.css";
import {
  CREATE_ROOM
} from "../constants/ActionTypes";

class RoomListItem extends PureComponent {
  selectRoomHandler = e => {
    this.props.selectRoomHandler(this.props.room.id);
  };

  render() {
    const { room, currentRoomId } = this.props;

    return (
      <li
        className={`rooms-list-item ${
          currentRoomId === room.id ? "rooms-list-item--current" : ""
        }`}
        onClick={this.selectRoomHandler}
        room_id={room.id}
      >
        <div className="content">
          <div className="room-text">{room.name}</div>
        </div>
      </li>
    );
  }
}

class RoomsList extends PureComponent {
  state = { roomName: ''};

  componentDidMount(){
  }

  getListRef = node => (this.list = node);

  insertName = (event)=>{
    this.setState({
      roomName: event.target.value
    })
  }

  createRoom = () => {
    const { socket } = this.props;
    const { roomName } = this.state;
    socket.emit(CREATE_ROOM, roomName);
  };

  render() {
    const { rooms } = this.props;

    const result = rooms && rooms.length > 0 ? (
        rooms.map((room, idx) => {
          return (
            <RoomListItem
              key={room.id}
              room={room}
              currentRoomId={this.props.currentRoomId}
              selectRoomHandler={this.props.selectRoomHandler}
            />
          );
        })
      ) : (
        <div className="rooms-list-empty"></div>
      );

    return (
      <>
      <ul ref={this.getListRef} className="rooms-list">
        {result}
      </ul>
      <input type="text" onChange={(event) => { this.insertName(event) }} />
      <button onClick={() =>this.createRoom()}>Add</button>
      </>
    );
  }
}

export default RoomsList;
