import * as constants from '../constants/ActionTypes';

const createRoom = (roomList, room) => {
  const newList = { ...roomList };
  newList[room.id] = room;
  return newList;
};

const changeColor = (roomList, randomColor, roomId) => {
  const newList = { ...roomList };
  if (newList[roomId]) {
    newList[roomId].color = randomColor;
  }
  return newList;
};

export default (state = [], action) => {
  switch (action.type) {
    case constants.ROOMS_UPDATED:
      return action.rooms;
    case constants.CREATE_ROOM:
      return createRoom(state, action.newRoom);
    case constants.COLORS_UPDATED:
      return changeColor(state, action.randomColor, action.roomId);
    default:
      return state;
  }
};
