import * as constants from '../constants/ActionTypes';

export default (state = null, action) => {
  switch (action.type) {
    case constants.SET_CURRENT_USER:
      return {
        id: action.id,
        userName: action.userName,
        currentRoomId: action.currentRoomId,
      };
    default:
      return state;
  }
};
