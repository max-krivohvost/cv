import io from 'socket.io-client';
import axios from 'axios';

import * as types from '../constants/ActionTypes';
import {
  addUser, removeUser, addRoom, changeColor,
} from '../actions';

const socketUrl = 'http://localhost:3232';

const setupSocket = (dispatch) => {
  const socket = io.connect(socketUrl);

  socket.on(types.USER_CONNECTED, ({ user }) => {
    dispatch(addUser(user));
  });

  socket.on(types.USER_DISCONNECTED, ({ userId }) => {
    dispatch(removeUser(userId));
  });

  socket.on(types.CREATE_ROOM, ({ newRoom }) => {
    dispatch(addRoom(newRoom));
    if (newRoom) {
      axios.put('/api/v1/addroom', newRoom);
    }
  });

  socket.on(types.NEXT_COLOR, ({ randomColor, roomId }) => {
    dispatch(changeColor({ randomColor, roomId }));
    if (randomColor && roomId) {
      axios.put(`/api/v1/updateRoom/${roomId}`, { color: randomColor });
    }
  });

  return socket;
};

export default setupSocket;
