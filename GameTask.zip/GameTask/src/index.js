import React from 'react';
import ReactDOM from 'react-dom';
import 'normalize.css';

import Root from './containers/Root';
import configureStore from './store';
import setupSocket from './sockets';

const store = configureStore();
const socket = setupSocket(store.dispatch, store.getState);

ReactDOM.render(
  <Root store={store} socket={socket} />,
  document.getElementById('root'),
);
