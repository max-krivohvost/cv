import * as types from '../constants/ActionTypes';

export const updateRooms = (rooms) => ({
  type: types.ROOMS_UPDATED,
  rooms,
  currentRoomId: rooms.currentRoomId,
});

export const addRoom = (newRoom) => ({
  type: types.CREATE_ROOM,
  newRoom,
});


export const changeColor = ({ randomColor, roomId }) => ({
  type: types.COLORS_UPDATED,
  randomColor,
  roomId,
});


export const setCurrentUser = (user) => ({
  type: types.SET_CURRENT_USER,
  id: user.id,
  userName: user.userName,
  currentRoomId: user.currentRoomId,
});

export const addUser = (user) => ({
  type: types.USER_CONNECTED,
  id: user.id,
  userName: user.userName,
  currentRoomId: user.currentRoomId,
});

export const removeUser = (userId) => ({
  type: types.USER_DISCONNECTED,
  userId,
});
