const uuidv4 = require('uuid/v4');
const { io } = require('./index.js');

const {
  USER_CONNECTED,
  USER_DISCONNECTED,
  ROOM_SELECTED,
  CREATE_ROOM,
  NEXT_COLOR,
} = require('./events');

const addUser = (userList, user) => {
  const newList = { ...userList };
  newList[user.id] = user;

  return newList;
};

const removeUser = (userList, userId) => {
  const newList = { ...userList };
  delete newList[userId];

  return newList;
};

let connectedUsers = {};
const DEFAULT_ROOM = 'cd1ac389-92dc-411e-99c3-256c295638cf';

module.exports = (socket) => {
  socket.on(USER_CONNECTED, (callback) => {
    if (!('userId' in socket) || !socket.userId) {
      const userId = uuidv4();
      const newUser = {
        id: userId,
        currentRoomId: DEFAULT_ROOM,
      };
      connectedUsers = addUser(connectedUsers, newUser);
      socket.userId = userId;    
      socket.currentRoomId = DEFAULT_ROOM;
      connectedUsers[userId].currentRoomId = DEFAULT_ROOM;

      io.emit(USER_CONNECTED, {
        user: connectedUsers[userId],
      });

      callback({
        result: true,
        user: connectedUsers[userId],
      });
    }
  });

  socket.on(CREATE_ROOM, (roomName) => {
    const newRoomId = uuidv4();
    const newRoom = {
      id: newRoomId,
      name: roomName,
      color: 'red',
    };
    io.emit(CREATE_ROOM, {
      newRoom,
    });
  });


  socket.on(NEXT_COLOR, () => {
    const user = connectedUsers[socket.userId];
    const roomId = user.currentRoomId;
    const randomColor = `#${((1 << 24) * Math.random() | 0).toString(16)}`;
    io.emit(NEXT_COLOR, { randomColor, roomId });
  });


  socket.on('disconnect', () => {
    if ('userId' in socket) {
      const user = connectedUsers[socket.userId];

      if (!user) {
        return;
      }

      connectedUsers = removeUser(connectedUsers, user.id);

      io.emit(USER_DISCONNECTED, {
        userId: user.id,
      });
    }
  });

  socket.on(ROOM_SELECTED, (newRoomId, callback) => {
    const user = connectedUsers[socket.userId];

    if (!user) {
      return;
    }

    if (newRoomId === user.currentRoomId) {
      callback({ result: true, user });
      return;
    }

    user.currentRoomId = newRoomId;

    io.emit(USER_CONNECTED, {
      user,
    });

    callback({ result: true, user });
  });
};
