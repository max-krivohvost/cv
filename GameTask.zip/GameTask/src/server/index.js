const http = require('http').createServer();
const io = (module.exports.io = require('socket.io')(http));

const PORT = process.env.PORT || 3232;

const SocketManager = require('./SocketManager');

io.on('connection', SocketManager);

http.listen(PORT, () => {
  console.log(`Connected to port:${  PORT}`);
});
