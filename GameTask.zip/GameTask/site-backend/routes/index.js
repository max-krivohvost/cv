const express = require('express');

const router = express.Router();
const { Pool } = require('pg');
const connectionData = require('../config');

router.put('/v1/addroom', (req, res) => {
  const pool = new Pool(connectionData);
  const { name, id } = req.body;
  const sql = `INSERT INTO rooms(roomid, name, color) values('${id}', '${name}', 'red')`;
  if (id && name) {
    pool.query(sql, (error, data) => {
      if (error) {
        throw error;
      }
      pool.end();
      return res.json(data.rows);
    });
  }
});

router.get('/v1/rooms', (req, res) => {
  const pool = new Pool(connectionData);
  const sql = 'SELECT * FROM rooms';
  pool.query(sql, (error, data) => {
    if (error) {
      throw error;
    }
    pool.end();
    return res.json(data.rows);
  });
});

router.put('/v1/updateRoom/:room_id', (req, res) => {
  const id = req.params.room_id;
  const { color } = req.body;
  const pool = new Pool(connectionData);
  const sql = `UPDATE rooms SET color = '${color}' WHERE roomid = '${id}'`;
  if (id && color) {
    pool.query(sql, (error, data) => {
      if (error) {
        throw error;
      }
      pool.end();
      return res.json(data);
    });
  }
});

module.exports = router;
