1.Create database called 'game' and table with name 'rooms'
```
CREATE TABLE public.rooms
(
    id integer NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1 ),
    name name NOT NULL,
    color text COLLATE pg_catalog."default",
    roomid text COLLATE pg_catalog."default",
    CONSTRAINT rooms_pkey PRIMARY KEY (id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.rooms
    OWNER to postgres;
```
2.Setup connection settings in file site-backend/config/index.js. In my case i have used not default port.
3.Go to site-backend folder and launch api server
```
npm start
```
and from root folder 
```
npm run react
```
4.It's possible create new rooms and change color. Every new click - random color will appear.
5 Enjoy :)

