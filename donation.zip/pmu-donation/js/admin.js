jQuery(document).ready(function ($) {
    gk_media_init('.images li a.media-button, .campaignslist a.media-button');

    jQuery('.save').click(function () {
        var data = jQuery('input[name="images[]"]').serialize();

        jQuery.post('/wp-admin/admin-ajax.php', {
            action: 'save_donation_img',
            data: data
        }, function (resp) {
            window.location.reload();
        })
    });

    jQuery(document).on('click', '[role="generate-cert"]', function() {
        var type = $('[name="cert_type"]:checked').val();
        var $img_url = $('[name="img_url"]:checked');

        var custom_title = '';
        switch (type) {
            case 'gift':
                custom_title = $('[name="headline"]').val();
                break;
            case 'funeral':
                custom_title = 'Till minne av|' + $('[name="name_deceased"]').val();
                break;
        }

        var selected_campaign = $('[name="campaign"]').val();
        var custom_text = $('[name="greeting"]').val();

        var params = {
            image_url: $img_url.val(),
            type: type,
            custom_title: custom_title,
            custom_text: custom_text,
            selected_campaign: selected_campaign,
        };

        params = JSON.stringify(params);
        var code = btoa(params);

        window.open('/certificate/?code=' + code + '&security_key=' + security_key);

        return false;
    });

    jQuery(document).on('change', '[name="cert_type"]', function() {
        var type = $(this).val();
        var $field_name_deceased_wrapper = $('.field_name_deceased');
        var $field_headline_wrapper = $('.field_headline');
        switch (type) {
            case 'gift':
                $field_name_deceased_wrapper.addClass('hidden');
                $field_headline_wrapper.removeClass('hidden');
                break;
            case 'funeral':
                $field_name_deceased_wrapper.removeClass('hidden');
                $field_headline_wrapper.addClass('hidden');
                break;
        }
    });

    jQuery(document).on('click', '[role="update-campaigns-order"]', function() {
        var params = {
            'action': 'update_campaigns_order'
        };

        $('[name^="order"]').each(function (i, val) {
            params['order[' + $(val).data('id') + ']'] = $(val).val();
        });

        $('.buttons-wrapper .spinner').css('visibility', 'visible');

        $.ajax({
            url: '/wp-admin/admin-ajax.php',
            method: 'post',
            data: params,
            success: function (resp) {
                window.location.reload();
            }
        });

        return false;
    });
});

var gk_media_init = function(selector)  {
    var clicked_button = false;

    jQuery(selector).each(function (i, input) {
        var button = jQuery(input);
        button.click(function (event) {
            event.preventDefault();
            var selected_img;
            clicked_button = jQuery(this);

            // check for media manager instance
            if(wp.media.frames.gk_frame) {
                wp.media.frames.gk_frame.open();
                return;
            }
            // configuration of the media manager new instance
            wp.media.frames.gk_frame = wp.media({
                title: 'Select image',
                multiple: false,
                library: {
                    type: 'image'
                },
                button: {
                    text: 'Use selected image'
                }
            });

            // Function used for the image selection and media manager closing
            var gk_media_set_image = function() {
                var selection = wp.media.frames.gk_frame.state().get('selection');

                // no selection
                if (!selection || !selection.length) {
                    clicked_button.prev().val('');
                    jQuery(clicked_button).removeClass('with-img');
                    jQuery(clicked_button).children().attr('src', '').addClass('hide');
                    return;
                }

                // iterate through selected elements
                selection.each(function(attachment) {
                    var id = attachment.attributes.id;
                    var url = attachment.attributes.url;
                    if (id !== '') {
                        clicked_button.prev().val(id + '|' + url);
                        jQuery(clicked_button).addClass('with-img');
                        jQuery(clicked_button).children().attr('src', url).removeClass('hide');
                    }
                });
            };

            // closing event for media manger
            wp.media.frames.gk_frame.on('close', gk_media_set_image);
            // image selection event
            wp.media.frames.gk_frame.on('select', gk_media_set_image);
            wp.media.frames.gk_frame.on('open',function() {
                var selection = wp.media.frames.gk_frame.state().get('selection');
                var val = jQuery(clicked_button).prev().val();
                val = val.split('|');
                var id = val[0];
                attachment = wp.media.attachment(id);
                attachment.fetch();
                selection.add(attachment ? [attachment] : []);
            });
            // showing media manager
            wp.media.frames.gk_frame.open();
        });
    });
};

