<?php

ini_set("soap.wsdl_cache_enabled", "0");
ini_set('display_errors', 'Off');
error_reporting(E_ALL);


/**
 * Class SoapClientCurl extends SoapClient __doRequest method with curl powered method
 */
class SoapClientCurl extends SoapClient
{

    //Required variables
    public $url = null;
    public $certfile = null;
    public $keyfile = null;
    public $passphrase = null;

    //Overwrite constructor and add our variables
    public function __construct($wsdl, $options = array())
    {
        $this->soap_version = SOAP_1_1;
        parent::__construct($wsdl, $options);

        foreach ($options as $field => $value) {
            if (!isset($this->$field)) {
                $this->$field = $value;
            }
        }
    }

    /**
     * Overwrite __doRequest and replace with cURL. Return XML body to be parsed with SoapClient
     */
    public function __doRequest($request, $location, $action, $version, $one_way = 0)
    {
        //Basic curl setup for SOAP call
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->url); //Load from datasource
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
//        curl_setopt($ch, CURLOPT_HEADER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: text/xml', 'SOAPAction: ""'));

        curl_setopt($ch, CURLOPT_POSTFIELDS, $request);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);

        //SSL
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSLCERT, $this->certfile);
        curl_setopt($ch, CURLOPT_SSLKEYTYPE, 'PEM');
        curl_setopt($ch, CURLOPT_SSLKEYPASSWD, $this->passphrase); //Load from datasource

        //Parse cURL response
        $response = curl_exec($ch);
        $this->curl_errorno = curl_errno($ch);

        if ($this->curl_errorno == CURLE_OK) {
            $this->curl_statuscode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        }
        $this->curl_errormsg = curl_error($ch);

        //Close connection
        curl_close($ch);

        //Return response info
        return $response;
    }
}

$env = getenv('ENVIRONMENT');
$identifierings_information = [ // dev settings
    'KundNrLeveransMottagare' => '500243',
    'KundNrSlutkund' => '500243',
    'OrgNrSlutkund' => '3102263153',
];

if ($env == 'dev') {
    $url = "https://kt-ext-ws.statenspersonadressregister.se/spar-webservice/SPARPersonsokningService/20160213/SPARPersonsokning.wsdl";
} else {
    $url = "https://ext-ws.statenspersonadressregister.se/spar-webservice/SPARPersonsokningService/20160213/SPARPersonsokning.wsdl";

    $identifierings_information = [
        'KundNrLeveransMottagare' => '502459',
        'KundNrSlutkund' => '502459',
        'OrgNrSlutkund' => '8020040575',
    ];
}

$cert_file = __DIR__ . '/pmu.pem';
$cert_password = '8128000014473446';

//Define options
$options = [
    'certfile' => $cert_file, // e.g. '/path/to/certfile.crt'
    'url' => $url, // e.g. 'https://webservice.example.com/'
    'passphrase' => $cert_password  // e.g. 'superSecretPassphrase'
];

//Init client
$client = new SoapClientCurl(__DIR__ . '/spar_updated.wsdl', $options);

//Request:
try {
    $params = $_POST;

    $resp = $client->SPARPersonsokning([
        'IdentifieringsInformation' => array_merge($identifierings_information, [
            'SlutAnvandarId' => 'PMU-160909',
            'Tidsstampel' => date('Y-m-d\TH:m:s.B')
        ]),
        'PersonsokningFraga' => [
            'PersonId' => [
                'FysiskPersonId' => str_replace('-', '', $params['personal_number']) // 188308089351
            ],
        ],
    ]);

    $personalInfo = $resp->PersonsokningSvarsPost->Persondetaljer;
    $address = $resp->PersonsokningSvarsPost->Adresser;

    usort($address->Folkbokforingsadress, function ($a, $b) {
        if (strtotime($a->DatumFrom) == strtotime($b->DatumFrom)) {
            return 0;
        }
        return (strtotime($a->DatumFrom) < strtotime($b->DatumFrom) ? -1 : 1);
    });

    $address = array_pop($address->Folkbokforingsadress);

    $response = [
//        'response' => $resp,
//        'response2' => $address,
        'first_name' => $personalInfo->Fornamn,
        'last_name' => $personalInfo->Efternamn,
        'street_address' => $address->Utdelningsadress2,
        'zip_code' => $address->PostNr,
        'city' => $address->Postort,
    ];

    echo json_encode($response);
    die();


} catch (SoapFault $e) {
    echo $e->getMessage();
}

