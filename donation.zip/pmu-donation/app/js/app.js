var app = app || {};


_.extend(Backbone.Validation.callbacks, {
    valid: function (view, attr, selector) {
        var $el = view.$('[name=' + attr + ']'),
            $group = $el.closest('#donation-area');

        if (attr === 'cert_type') {
            $group.find('.gift-step').removeClass('has-error')
        }

        if (attr === 'selectedCampaignValue') {
            jQuery('#donation-campaign').removeClass('has-error');
        }

        if (attr === 'selectedGiverType') {
            jQuery('#attr_giverType').removeClass('has-error');
        }

        $el.removeClass('has-error');

        if (Backbone.history.getFragment() == 'giftpage' && attr == 'backgroundUrl') {
            var $img = jQuery('.donation-gift-preview');

            $img.removeClass('has-error');
        }

        var err = jQuery('#donation-area').find('.has-error');

        if (err.length == 0) {
            jQuery('.error-message-donation').hide();
        }

        if (Backbone.history.getFragment() == '' || Backbone.history.getFragment() == 'amount') {
            if (!view.$('[name="cert_type"]').hasClass('has-error')) {
                jQuery('.error-message-donation-2').hide();
            }

            if (!view.$('#donation-campaign').hasClass('has-error')
                && !view.$('#attr_giverType').hasClass('has-error')) {
                jQuery('.error-message-donation-campaign').hide();
            }

            if (!view.$('[name="amount"]').hasClass('has-error')) {
                jQuery('.error-message-donation').hide();
            }
        }
    },
    invalid: function (view, attr, error, selector) {
        var $el = view.$('[name=' + attr + ']'),
            $group = $el.closest('#donation-area');

        if (attr === 'cert_type') {
            $group.find('.gift-step').addClass('has-error');

            jQuery('.error-message-donation-2').html(error).show();
        }

        if (attr === 'selectedGiverType') {
            jQuery('#attr_giverType').addClass('has-error');
            jQuery('.error-message-donation-campaign').html(error).show();
        }

        if (attr === 'selectedCampaignValue') {
            jQuery('#donation-campaign').addClass('has-error');
            jQuery('.error-message-donation-campaign').html(error).show();
        }

        if (Backbone.history.getFragment() === 'giftpage' && attr === 'backgroundUrl') {
            var $img = jQuery('.donation-gift-preview');

            $img.addClass('has-error');
        }

        if ($el.is(':disabled')) {
            $el.removeClass('has-error');
        } else {
            $el.addClass('has-error');
        }

        var err = jQuery('#donation-area').find('.has-error');

        if (err.length === 0) {
            jQuery('.error-message-donation').hide();
        } else {
            if (Backbone.history.getFragment() === '' || Backbone.history.getFragment() === 'amount') {
                if (attr !== 'cert_type' && attr !== 'selectedCampaignValue' && attr !== 'selectedGiverType') {
                    jQuery('.error-message-donation').html(error);
                }
            }

            if (attr !== 'cert_type' && attr !== 'selectedCampaignValue' && attr !== 'selectedGiverType') {
                jQuery('.error-message-donation').show();
            }
        }
    }
});

app.DonationView = Backbone.View.extend({
    el: '#donation-area',
    statsTemplate: Handlebars.compile(jQuery('#amount-template').html()),
    statsTemplateBusiness: Handlebars.compile(jQuery('#amount-template-for-business').html()),
    stepsView: new app.StepsView(),
    events: {
        'click .gift-checkbox': 'renderSteps',

        'click input[name="cert_type"]': 'certTypeSelect',

        'click .donation-left-button': function (e) {
            this.model.attributes.paymentType = 'PMU_DONATION_directbank_v2';
            if (this.nextStep() === true) {
                if (typeof myTodoRouter.kontaktinfoModel.attributes.bankDibs == 'undefined') {

                    myTodoRouter.kontaktinfoModel.attributes.bankDibs = 'direct.fsb';
                }
                myTodoRouter.navigate('kontaktinfo', true);
            }
        },
        'click .donation-right-button': function () {
            this.model.attributes.paymentType = 'PMU_DONATION_kort_v2';
            if (this.nextStep() === true) {
                myTodoRouter.navigate('kontaktinfo', true);
            }
        },
        'click .information': function (e) {
        },
        'click .amountOption': function (e) {
            if (jQuery('.amountOption:checked').val() == 'custom') {
                jQuery('.donation-amount').prop("disabled", false);
            } else {
                jQuery('.donation-amount').prop("disabled", true);
                this.model.isValid(true)
            }
        }
    },
    bindings: {
        '[name=amount]': {
            observe: 'amount',
        },
        '[name=amountOption]': {
            observe: 'amountOption',
        },
        '[name=gift-checkbox]': {
            observe: 'giftcheckbox',
        },
        '[name=cert_type]': {
            observe: 'cert_type',
        }
    },

    initialize: function () {

        Handlebars.registerHelper('isSelected', function (selected) {
            return selected === 1 ? 'selected' : '';
        });


        this.render();

        Backbone.Validation.bind(this);
    },
    nextStep: function () {
        if (this.model.isValid(true)) {
            return true;
        } else {
            return false;
        }

    },
    render: function () {
        if (is_business) {
            this.$el.html(this.statsTemplateBusiness(this.model.toJSON()));
        } else {
            this.$el.html(this.statsTemplate(this.model.toJSON()));
        }

        var self = this;

        var render = true;
        jQuery('#donation-campaign').ddslick({
            data: this.model.attributes.campaigns,
            width: 410,
            background: '#fff',
            imagePosition: "left",
            onSelected: function (selectedData) {
                myTodoRouter.amountModel.set('selectedCampaign', selectedData.selectedData.id);
                myTodoRouter.amountModel.set('selectedCampaignValue', selectedData.selectedData.value);

                if (!render || myTodoRouter.amountModel.attributes.selectedCampaign === ''
                    || myTodoRouter.amountModel.attributes.selectedCampaign == null) {

                    if (!render) {
                        self.model.isValid('selectedCampaignValue');
                    }

                    if (selectedData.selectedData.id !== null) {
                        jQuery('#donation-campaign').removeClass('not-selected');
                    } else {
                        jQuery('#donation-campaign').addClass('not-selected');
                    }
                } else if (!render) {
                    jQuery('#donation-campaign').addClass('not-selected');
                } else {
                    render = false;
                }
            }
        });

        if (myTodoRouter.amountModel.attributes.giftcheckbox) {
            jQuery('.cert-type').removeClass('hidden');
        }

        this.stickit();

        var campaigns_ids = {};
        jQuery.each(campaigns, function (i, obj) {
            campaigns_ids[obj.id] = i;
        });

        jQuery('#donation-area form').submit(function () {
            return false;
        });

        jQuery('#donation-campaign').ddslick('select', {index: campaigns_ids[myTodoRouter.amountModel.attributes.selectedCampaign]});
        if (is_business) {
            jQuery('.gift-step').remove();
        }
        return this;
    },
    renderSteps: function (event) {
        var checkboxStatus = event.currentTarget.checked;
        var stepsView = this.stepsView;

        if (checkboxStatus) {
            jQuery('.cert-type').removeClass('hidden');
            stepsView.renderAdvanced();
            myTodoRouter.kontaktinfoModel.attributes.kontaktbutton = 'Fortsätt';
        } else {
            jQuery('.cert-type').addClass('hidden');
            stepsView.renderBasic();
            myTodoRouter.kontaktinfoModel.attributes.kontaktbutton = 'Ge din gåva!';
        }

        if (checkboxStatus && myTodoRouter.amountModel.attributes.cert_type == 'gift') {
            myTodoRouter.amountModel.attributes.donation_type = 2;
        } else if (checkboxStatus) {
            myTodoRouter.amountModel.attributes.donation_type = 3;
        } else {
            myTodoRouter.amountModel.attributes.donation_type = 1;
        }

        return true;
    },
    certTypeSelect: function (event) {
        if (jQuery(event.currentTarget).val() == 'gift') {
            myTodoRouter.amountModel.attributes.donation_type = 2;
        } else {
            myTodoRouter.amountModel.attributes.donation_type = 3;
        }
    }
});


app.GiftView = Backbone.View.extend({

    el: '#donation-area',
    statsTemplate: Handlebars.compile(jQuery('#gift-template').html()),
    events: {
        'click .donation-gift-previewitem': 'previewImage',
        'change .sendOption': 'changeAddress',
        'click .donation-gonext': 'processPayment',
        'click .donationContact': 'fillAddress',
        'click .preview-button': 'previewCert'
    },
    bindings: {
        '[name=headline]': {
            observe: 'headline'
        },
        '[name=name_deceased]': {
            observe: 'name_deceased'
        },
        '[name=greeting]': {
            observe: 'greeting'
        },
        '[name=sendOption]': {
            observe: 'sendOption'
        },
        '[name=name_gift]': {
            observe: 'name_gift'
        },
        '[name=street_gift]': {
            observe: 'street_gift'
        },
        '[name=zipcode_gift]': {
            observe: 'zipcode_gift'
        },
        '[name=city_gift]': {
            observe: 'city_gift'
        },
        '[name=arrivaldate]': {
            observe: 'arrivaldate'
        },
        '[name=deceaseds_name]': {
            observe: 'deceaseds_name'
        },
    },
    initialize: function () {
        jQuery('#donation-area').off('click', '.preview-button');
        jQuery('#donation-area').off('click', '.donation-gonext');
        this.render();
        Backbone.Validation.bind(this);
    },
    render: function () {
        this.$el.html(this.statsTemplate());
        this.stickit();
        if (this.model.attributes.backgroundUrl) {
            jQuery('.donation-gift-preview').css('background-image', this.model.attributes.backgroundUrl);
        }
        this.changeAddress();


        if (myTodoRouter.amountModel.attributes.giftcheckbox && myTodoRouter.amountModel.attributes.cert_type == 'funeral') {
            jQuery('label[for="sendOptionNo"]').html('Jag vill att PMU skriver ut och skickar gåvobeviset (30 kr för porto tillkommer)');
            jQuery('input[name="arrivaldate"]').attr('placeholder', 'Begravningsdatum');
            jQuery('input[name="name_gift"]').attr('placeholder', 'Namn/Begravningsbyrå*');
            jQuery('input[name="city_gift"]').attr('placeholder', 'Ort*');
            jQuery('.donation-gift-title').html('Ange vart du vill att minnesbladet ska skickas.');
            myTodoRouter.giftModel.attributes.headline = 'Till minne av';
            jQuery('input[name="headline"]').attr('value', 'Till minne av').addClass('hidden');
            jQuery('.headline').removeClass('hidden').html('Till minne av');

            jQuery('textarea[name="greeting"]').attr('placeholder', 'Hälsning och underskrift');
            jQuery('.arrivaldate').datepicker({
                // minDate:'+4d'
            });
        } else {
            if (myTodoRouter.giftModel.attributes.headline == 'Till minne av') {
                myTodoRouter.giftModel.attributes.headline = '';
                jQuery('input[name="headline"]').attr('value', '');
            }
            jQuery('input[name="deceaseds_name"], input[name="name_deceased"]').remove();
            jQuery('.arrivaldate').datepicker({
                minDate: '+4d'
            });

            var startDate = new Date();
            startDate.setHours(0);
            startDate.setMinutes(0);
            startDate.setSeconds(0);
            startDate = (startDate.getTime() + 4 * 24 * 60);
            if (jQuery('.arrivaldate').val() != '' && new Date(jQuery('.arrivaldate').val()).getTime() < startDate) {
                jQuery('.arrivaldate').val('');
            }
        }

        return this;
    },
    nextStep: function () {
        if (this.model.isValid(true) || jQuery('.sendOption:checked').val() == 'nosend'
            && this.model.isValid('headline')
            && this.model.isValid('name_deceased')
            && this.model.isValid('greeting')
            && this.model.isValid('backgroundUrl')) {
            return true;
        } else {
            return false;
        }
    },
    processPayment: function () {
        if (this.nextStep()) {
            jQuery('#donation-area .donation-button').hide();
            jQuery('#donation-area .process').removeClass('hidden');
            myTodoRouter.amountModel.initialProcessPayment(this);
        }
    },
    fillAddress: function () {
        var kontaktModel = myTodoRouter.kontaktinfoModel.attributes;
        if (jQuery('.donationContact:checked').val() == 'useAddress') {
            jQuery('.donation-gift-address input[name="name_gift"]').val(kontaktModel.firstname + " " + kontaktModel.lastname);
            jQuery('.donation-gift-address input[name="street_gift"]').val(kontaktModel.street);
            jQuery('.donation-gift-address input[name="zipcode_gift"]').val(kontaktModel.zipcode);
            jQuery('.donation-gift-address input[name="city_gift"]').val(kontaktModel.city);
            var name = kontaktModel.firstname + " " + kontaktModel.lastname;
            this.model.set('name_gift', name);
            this.model.set('street_gift', kontaktModel.street);
            this.model.set('zipcode_gift', kontaktModel.zipcode);
            this.model.set('city_gift', kontaktModel.city);

        } else {
            jQuery('.donation-gift-address input[name="name_gift"]').val('');
            jQuery('.donation-gift-address input[name="street_gift"]').val('');
            jQuery('.donation-gift-address input[name="zipcode_gift"]').val('');
            jQuery('.donation-gift-address input[name="city_gift"]').val('');
            this.model.set('name_gift', '');
            this.model.set('street_gift', '');
            this.model.set('zipcode_gift', '');
            this.model.set('city_gift', '');
        }
    },
    changeAddress: function () {
        if (jQuery('.sendOption:checked').val() == 'send') {
            jQuery('.donation-gift-address').css('display', 'inline-block');
        } else {
            jQuery('.donation-gift-address').hide();
        }
    },
    previewImage: function (event) {
        jQuery('.donation-gift-preview').css('background-image', jQuery(event.target).css('background-image'));
        if (jQuery(window).width() <= 736) {
            jQuery("html, body").animate({scrollTop: jQuery('.donation-gift-left').offset().top}, 500);

        }
        this.model.set('backgroundUrl', jQuery(event.target).css('background-image'));
    },
    previewCert: function() {
        // option=preview&code=

        if (this.nextStep()) {
            var headline = myTodoRouter.giftModel.attributes.headline;

            if (myTodoRouter.amountModel.attributes.cert_type == 'funeral') {
                headline += '|' + myTodoRouter.giftModel.attributes.name_deceased;
            }
            var code = _.extend({}, {
                image: myTodoRouter.giftModel.attributes.backgroundUrl,
                headline: headline,
                greeting: myTodoRouter.giftModel.attributes.greeting
            }, {
                campaign_id: myTodoRouter.amountModel.attributes.selectedCampaign
            });

            code = btoa(JSON.stringify(code));

            var url = '/certificate/?option=preview&code=' + code;

            window.open(url, '_blank');
        }
    }
});


app.KontaktView = Backbone.View.extend({

    el: '#donation-area',
    statsTemplate: Handlebars.compile(jQuery('#kontaktinfo-template').html()),
    bindings: {
        '[name=organisation_number]': {
            observe: 'organisation_number'
        },
        '[name=company]': {
            observe: 'company'
        },
        '[name=contact]': {
            observe: 'contact'
        },
        '[name=firstname]': {
            observe: 'firstname'
        },
        '[name=lastname]': {
            observe: 'lastname'
        },
        '[name=email]': {
            observe: 'email',
        },
        '[name=phone]': {
            observe: 'phone',
        },
        '[name=street]': {
            observe: 'street',
        },
        '[name=zipcode]': {
            observe: 'zipcode',
        },
        '[name=city]': {
            observe: 'city',
        },
        '[name=goanonym]': {
            observe: 'goanonym'
        },
        '[name=bankDibs]': {
            observe: 'bankDibs'
        },
        '[name=personnumber]': {
            observe: 'personnumber'
        },
        '[name=bankname]': {
            observe: 'bankname'
        },
        '[name=clearingnumber]': {
            observe: 'clearingnumber'
        },
        '[name=personaccount]': {
            observe: 'personaccount'
        },
        '[name=deliveryOption]': {
            observe: 'deliveryOption'
        }
    },
    events: {
        'click .donation-godibs': 'processPayment',
        'click .goanonym': 'setAnonym',
        'click .get-address': 'getAddress',
        'click [name=goanonym]': 'changeGoAnonym',
        'keyup [name=personnumber]': 'changePersonNumber',
    },
    initialize: function () {
        // this.render();
        jQuery('#donation-area').off('click', '.donation-godibs');
        jQuery('#donation-area').off('click', '.get-address');
        Backbone.Validation.bind(this);

    },
    render: function () {
        this.$el.html(this.statsTemplate(this.model.toJSON()));
        this.stickit();
        this.setAnonym();

        if (typeof myTodoRouter.kontaktinfoModel.attributes.personnumber == 'undefined'
            || myTodoRouter.kontaktinfoModel.attributes.personnumber.length == 0) {
            jQuery('button.get-address').addClass('disable');
        } else {
            jQuery('button.get-address').removeClass('disable');
        }

        if (jQuery('.recurring').length > 0) {
            myTodoRouter.kontaktinfoModel.attributes.kontaktbutton = 'Bekräfta';
            jQuery('.recurring [name="personnumber"]').attr('placeholder', 'ÅÅÅÅMMDD-XXXX*');
            // jQuery('.recurring [name="personnumber"]').mask('00000000-0000');
            jQuery('.recurring [name="clearingnumber"]').mask('0000');
            jQuery('.recurring [name="personaccount"]').mask('0000000000000');

        } else {
            jQuery('.recurring-fields').remove();
        }

        jQuery('[name="personnumber"]').mask('00000000-0000');

        if (is_business) {
            jQuery('input[name="firstname"], input[name="lastname"], input[name="phone"]').remove();
            jQuery('.donation-anonymous').html('');
        } else {
            jQuery('input[name="organisation_number"], input[name="company"], input[name="contact"]').remove();
        }

        return this;
    },

    changePersonNumber: function() {
        if (jQuery('[name="personnumber"]').val().length == 0) {
            myTodoRouter.kontaktinfoModel.set('personnumber', null);
        }
        myTodoRouter.kontaktinfoModel.set('personnumber', jQuery('[name="personnumber"]').val());

        var isValid = myTodoRouter.kontaktinfoModel.isValid('personnumber');
        if (myTodoRouter.kontaktinfoModel.attributes.personnumber.length == 0
            || !isValid) {
            jQuery('button.get-address').addClass('disable');
        } else {
            jQuery('button.get-address').removeClass('disable');
        }
    },

    changeGoAnonym: function() {
        myTodoRouter.kontaktinfoModel.isValid(true);

        if (myTodoRouter.kontaktinfoModel.attributes.goanonym) {
            jQuery('button.get-address').addClass('disable');
        } else {
            if (typeof myTodoRouter.kontaktinfoModel.attributes.personnumber == 'undefined'
                || myTodoRouter.kontaktinfoModel.attributes.personnumber.length == 0) {
                jQuery('button.get-address').addClass('disable');
            } else {
                jQuery('button.get-address').removeClass('disable');
            }
        }
    },

    nextStep: function () {
        if (this.model.isValid(true) || myTodoRouter.kontaktinfoModel.attributes.goanonym == true) {
            return true;
        } else {
            return false;
        }
    },
    processPayment: function () {
        if (jQuery('.giftstep').length > 0) {
            if (this.nextStep() === true) {
                myTodoRouter.navigate('giftpage', true);
            }
        } else {
            if (jQuery('.recurring').length > 0) {
                if (this.nextStep() === true) {
                    jQuery('#donation-area .donation-button').hide();
                    jQuery('#donation-area .process').removeClass('hidden');
                    jQuery('#donation-area .process .additional-message').removeClass('hidden');

                    myTodoRouter.recurringModel.initialRecurringProcess(this);
                }
            } else {
                if (this.nextStep() === true) {
                    jQuery('#donation-area .donation-button').hide();
                    jQuery('#donation-area .process').removeClass('hidden');
                    myTodoRouter.amountModel.initialProcessPayment(this);
                }
            }
        }
    },
    setAnonym: function () {

        if (jQuery('.goanonym:checked').val() == 'on') {
            //jQuery('.donation-information-block').hide();
            if(typeof myTodoRouter.kontaktinfoModel.attributes  !== 'undefined'){
                myTodoRouter.kontaktinfoModel.set('city','');
                myTodoRouter.kontaktinfoModel.set('email','');
                myTodoRouter.kontaktinfoModel.set('firstname','');
                myTodoRouter.kontaktinfoModel.set('lastname','');
                myTodoRouter.kontaktinfoModel.set('phone','');
                myTodoRouter.kontaktinfoModel.set('street','');
                myTodoRouter.kontaktinfoModel.set('zipcode','');
            }
            jQuery(".donation-information-block input").prop("disabled", true);
        } else {
            //jQuery('.donation-information-block').show();
            jQuery(".donation-information-block input").prop("disabled", false);
        }
    },
    getAddress: function() {
        if (jQuery('button.get-address').hasClass('disable')) {
            return false;
        }
        jQuery('button.get-address').addClass('disable');
        jQuery('div.process-get-address').removeClass('hidden');

        if (myTodoRouter.kontaktinfoModel.attributes.personnumber.length == 0) {
            return false;
        }

        jQuery.ajax({
            url: '/wp-json/process-donation/get-address',
            type: 'post',
            dataType: 'json',
            data: {
                personal_number: myTodoRouter.kontaktinfoModel.attributes.personnumber
            },
            success: function (resp) {
                if (resp.first_name != null) {
                    myTodoRouter.kontaktinfoModel.set({
                        "firstname": " ",
                        "lastname": " ",
                        "street": " ",
                        "zipcode": " ",
                        "city": " ",
                    });

                    myTodoRouter.kontaktinfoModel.set({
                        "firstname": resp.first_name,
                        "lastname": resp.last_name,
                        "street": resp.street_address,
                        "zipcode": resp.zip_code,
                        "city": resp.city,
                    });
                }

                if (jQuery('[name="firstname"]').length > 0) {
                    jQuery('[name="firstname"]').val(hide_part_of_string(jQuery('[name="firstname"]').val()));
                }

                if (jQuery('[name="lastname"]').length > 0) {
                    jQuery('[name="lastname"]').val(hide_part_of_string(jQuery('[name="lastname"]').val()));
                }

                if (jQuery('[name="street"]').length > 0) {
                    jQuery('[name="street"]').val(hide_part_of_string(jQuery('[name="street"]').val()));
                }

                if (jQuery('[name="zipcode"]').length > 0) {
                    jQuery('[name="zipcode"]').val(hide_part_of_string(jQuery('[name="zipcode"]').val()));
                }

                if (jQuery('[name="city"]').length > 0) {
                    jQuery('[name="city"]').val(hide_part_of_string(jQuery('[name="city"]').val()));
                }

                jQuery('[name="firstname"], [name="lastname"], [name="street"], [name="zipcode"], [name="city"]').off('keydown');
                jQuery('[name="firstname"], [name="lastname"], [name="street"], [name="zipcode"], [name="city"]').on('keydown', function() {
                    jQuery(this).off('keydown').val('');
                });

                jQuery('div.process-get-address').addClass('hidden');
                jQuery('button.get-address').removeClass('disable');

                myTodoRouter.kontaktinfoModel.isValid(true);
            }
        });

        return false;
    }
});

function hide_part_of_string(string) {
    if (string == '') {
        return string;
    }
    var strArr = [];
    string.split(' ').forEach(function(str) {
        strArr.push(str.substr(0, 1) + '*'.repeat(str.length - 1));
    });

    return strArr.join(' ');
}


app.RecurringView = Backbone.View.extend({
    el: '#donation-area',
    statsTemplate: Handlebars.compile(jQuery('#recurring-template').html()),
    bindings: {
        '[name=amount]': {
            observe: 'amount'
        },
        '[name=amountOption]': {
            observe: 'amountOption'
        }
    },
    events: {
        'click .donation-godibs': function (e) {

            if (Backbone.history.getFragment() == 'amount' || Backbone.history.getFragment() == '') {
                if (myTodoRouter.recurringModel.isValid(true)) {
                    myTodoRouter.navigate('kontaktinfo', true);
                }
            }
        },
        'click .amountOption': function (e) {
            if (jQuery('.amountOption:checked').val() == 'custom') {
                jQuery('.donation-amount').prop("disabled", false);
            } else {
                jQuery('.donation-amount').val('');
                this.model.attributes.amount = '';
                jQuery('.donation-amount').prop("disabled", true);
                this.model.isValid(true)
            }
        }
    },
    initialize: function () {
        jQuery('#donation-area').off('click', '.donation-godibs');
        Handlebars.registerHelper('isSelected', function (selected) {
            return selected === 1 ? 'selected' : '';
        });

        this.render();
        Backbone.Validation.bind(this);
    },
    render: function () {
        this.$el.html(this.statsTemplate(this.model.toJSON()));

        var self = this;

        var render = true;
        jQuery('#attr_giverType').ddslick({
            data: this.model.attributes.giverTypeList,
            width: 410,
            background: '#fff',
            imagePosition: "left",
            onSelected: function (selectedData) {
                if (!render || myTodoRouter.recurringModel.attributes.selectedGiverType == '') {
                    myTodoRouter.recurringModel.set('selectedGiverType', selectedData.selectedData.value);
                    self.model.isValid('selectedGiverType');
                    if (selectedData.selectedData.value !== null) {
                        jQuery('#attr_giverType').removeClass('not-selected');
                    }
                } else {
                    jQuery('#attr_giverType').addClass('not-selected');
                    render = false;
                }
            }
        });

        this.stickit();

        var campaigns_ids = {};
        jQuery.each(myTodoRouter.recurringModel.attributes.giverTypeList, function (i, obj) {
            campaigns_ids[obj.value] = i;
        });

        jQuery('#donation-area form').submit(function () {
            return false;
        });

        jQuery('#attr_giverType').ddslick('select', {index: campaigns_ids[myTodoRouter.recurringModel.attributes.selectedGiverType]});
        return this;
    }
});


