var app = app || {};

var TodoRouter = Backbone.Router.extend({

    routes: {
        "giftpage" : "showGift",
        "kontaktinfo" : "showKontaktinfo",
        "*amount" : "defaultRoute",
    },
    amountModel: new app.Amount(),
    kontaktinfoModel: new app.Kontakt(),
    giftModel: new app.Gift(),
    checkoutModel: new app.CheckoutModel(),
    checkoutRecurringModel: new app.CheckoutRecurringModel(),
    recurringModel: new app.Reccuring(),
    showGift: function(){
        var giftView = new app.GiftView({model:this.giftModel});
        jQuery('#donation-steps li').removeClass('donation-current-step');
        jQuery('a[href$="giftpage"]').parent( "li" ).addClass('donation-current-step');
        giftView.render();
        if(myTodoRouter.kontaktinfoModel.attributes.goanonym === true){
            jQuery('.error-message-donation').delay(500).hide(0);
            jQuery('.donation-anonymous').remove();
        }
    },
    initialize:function(){
        jQuery( ".donation-tab" ).click(function() {
            var url = jQuery(this).data('link');
            window.location.href = url;
        });
        parent.location.hash = '';
    },
    showKontaktinfo: function(event){
        var kontaktView = new app.KontaktView({model:this.kontaktinfoModel});
        kontaktView.render();
        jQuery('#donation-steps li').removeClass('donation-current-step');
        jQuery('a[href$="kontaktinfo"]').parent( "li" ).addClass('donation-current-step');

        kontaktView.render();

        if(this.amountModel.attributes.paymentType == 'PMU_DONATION_directbank_v2' ){
            myTodoRouter.kontaktinfoModel.attributes.goanonym = false;
            // jQuery('.donation-anonymous').hide();
            jQuery('.donation-bank').show();
        }else{
            jQuery('.donation-anonymous').show();
            jQuery('.donation-bank').hide();
        }
    },

    defaultRoute: function(){
        if(jQuery('.donation-block').hasClass('recurring')){
            var recurringVIew = new app.RecurringView({model:this.recurringModel});
            recurringVIew.render();
            if(jQuery('.amountOption:checked').val() == 'custom'){
                jQuery('.donation-amount').prop("disabled", false);
            }else{
                jQuery('.donation-amount').prop("disabled", true);
            }

            if(this.recurringModel.attributes.amountOption === '' && this.recurringModel.attributes.amount === '' ){
                this.recurringModel.set('amountOption',200);
            }else{
                //this.amountModel.set('amountOption','custom');
            }
        }else{
            var amountView = new app.DonationView({model:this.amountModel});
            jQuery('#donation-steps li').removeClass('donation-current-step');
            jQuery('a[href$="amount"]').parent( "li" ).addClass('donation-current-step');
            amountView.render();

            if(this.amountModel.attributes.amountOption === '' && this.amountModel.attributes.amount === '' ){
                if (is_business) {
                    this.amountModel.set('amountOption',5000);
                } else {
                    this.amountModel.set('amountOption', 200);
                }
            }else{
                //this.amountModel.set('amountOption','custom');
            }

            if(jQuery('.amountOption:checked').val() == 'custom'){
                jQuery('.donation-amount').prop("disabled", false);
            }else{
                jQuery('.donation-amount').prop("disabled", true);
            }
        }

    }
});

var myTodoRouter = new TodoRouter();
Backbone.history.start({root: '/'});