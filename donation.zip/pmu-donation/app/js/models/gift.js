var app = app || {};

app.Gift = Backbone.Model.extend({

        defaults: {
            backgroundUrl: ''
        },
        validation: {
            headline: {
                required: true,
            },
            name_deceased: function (val, attr, computed) {
                if (myTodoRouter.amountModel.attributes.giftcheckbox && myTodoRouter.amountModel.attributes.cert_type == 'funeral') {
                    var err = Backbone.Validation.validators.required(val, attr, this);
                    if (typeof err != 'undefined') {
                        this._isValid = false;
                        return err;
                    }
                }

                return;
            },
            greeting: {
                required: true,
            },
            backgroundUrl: {
                required: true,
            },
            name_gift: function (val, attr, computed) {
                if (myTodoRouter.giftModel.attributes.sendOption == 'send') {
                    var err = Backbone.Validation.validators.required(val, attr, this);
                    if (typeof err != 'undefined') {
                        this._isValid = false;
                        return err;
                    }
                }

                return;
            },
            street_gift: function (val, attr, computed) {
                if (myTodoRouter.giftModel.attributes.sendOption == 'send') {
                    var err = Backbone.Validation.validators.required(val, attr, this);
                    if (typeof err != 'undefined') {
                        this._isValid = false;
                        return err;
                    }
                }

                return;
            },
            city_gift: function (val, attr, computed) {
                if (myTodoRouter.giftModel.attributes.sendOption == 'send') {
                    var err = Backbone.Validation.validators.required(val, attr, this);
                    if (typeof err != 'undefined') {
                        this._isValid = false;
                        return err;
                    }
                }

                return;
            },
            zipcode_gift: function (val, attr, computed) {
                if (myTodoRouter.giftModel.attributes.sendOption == 'send') {
                    var err = Backbone.Validation.validators.required(val, attr, this);
                    if (typeof err != 'undefined') {
                        this._isValid = false;
                        return err;
                    }
                }

                return;
            },
            deceaseds_name: function (val, attr, computed) {
                if (myTodoRouter.amountModel.attributes.giftcheckbox
                    && myTodoRouter.amountModel.attributes.cert_type == 'funeral'
                    && myTodoRouter.giftModel.attributes.sendOption == 'send') {

                    var err = Backbone.Validation.validators.required(val, attr, this);
                    if (typeof err != 'undefined') {
                        this._isValid = false;
                        return err;
                    }
                }

                return;
            },
            arrivaldate: function (val, attr, computed) {
                if (myTodoRouter.amountModel.attributes.giftcheckbox
                    && myTodoRouter.giftModel.attributes.sendOption == 'send') {

                    var err = Backbone.Validation.validators.required(val, attr, this);
                    if (typeof err != 'undefined') {
                        this._isValid = false;
                        return err;
                    }
                }

                return;
            }
        },
        initialize: function () {
        },
        toggle: function () {
            this.save({
                completed: !this.get('completed')
            });
        }
    }
);


app.Reccuring = Backbone.Model.extend({
    defaults: {
        amountOption: '',
        amount: '',
        giverTypeList: recurring_campaigns,
        selectedGiverType: '',
    },
    validation: {
        selectedGiverType: function (val, attr, computed)  {
            var err = Backbone.Validation.validators.required(val, attr, this);
            if (typeof err != 'undefined') {
                this._isValid = false;
                return 'Välj en kampanj';
            }
        },
        amount: function (val, attr, computed) {
            if (jQuery('#amountCustom').is(':checked')) {
                var err = Backbone.Validation.validators.required(val, attr, this);
                if (typeof err != 'undefined') {
                    this._isValid = false;
                    return 'Skriv en summa';
                }

                err = Backbone.Validation.validators.min(val, attr, 50, this);
                if (typeof err != 'undefined') {
                    this._isValid = false;
                    return 'Minsta belopp som du kan ge är 50 kr';
                }
            }
            return;
        },
        // attr_giverType: {
        //     required: true
        // }
    },
    initialize: function () {
        if (typeof(donation_amount) != "undefined") {
            this.set('amount', donation_amount);
        }
    },
    toggle: function () {
        this.save({
            completed: !this.get('completed')
        });
    },

    initialRecurringProcess: function (view) {
        jQuery.extend(myTodoRouter.checkoutRecurringModel.attributes, myTodoRouter.recurringModel.toJSON());
        jQuery.extend(myTodoRouter.checkoutRecurringModel.attributes, myTodoRouter.kontaktinfoModel.toJSON());

        if (myTodoRouter.checkoutRecurringModel.attributes.amount === '') {
            myTodoRouter.checkoutRecurringModel.set('amount', myTodoRouter.checkoutRecurringModel.attributes.amountOption);
        }

        myTodoRouter.checkoutRecurringModel.set('donation_type', 5);

        myTodoRouter.checkoutRecurringModel.save(null, {
            success: function (model, response) {
                if (typeof response.code !== 'undefined') {
                    var el = jQuery('<form method="post">');
                    jQuery(el).append('<input name="code" value="' + response.code + '">');
                    jQuery('body').append(el);
                    el.trigger('submit');
                    el.remove();
                } else if (typeof response.redirect_to !== 'undefined') {
                    window.location.href = response.redirect_to;
                }
            },
            error: function (model, response) {

            }
        });
    }

});

app.CheckoutRecurringModel = Backbone.Model.extend({
    url: "/wp-json/process-donation/neworder/",
});