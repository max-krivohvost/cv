var app = app || {};

app.Kontakt = Backbone.Model.extend({

    defaults: {
        kontaktbutton:'Ge din gåva!',
    },
    validation: {
        organisation_number: function (val, attr, computed) {
            if (is_business) {
                var err = Backbone.Validation.validators.required(val, attr, this);
                if (typeof err != 'undefined') {
                    this._isValid = false;
                    return err;
                }
            }
            return;
        },
        company: function (val, attr, computed) {
            if (is_business) {
                var err = Backbone.Validation.validators.required(val, attr, this);
                if (typeof err != 'undefined') {
                    this._isValid = false;
                    return err;
                }
            }
            return;
        },
        contact: function (val, attr, computed) {
            if (is_business) {
                var err = Backbone.Validation.validators.required(val, attr, this);
                if (typeof err != 'undefined') {
                    this._isValid = false;
                    return err;
                }
            }
            return;
        },

        firstname: function (val, attr, computed) {
            if (!is_business) {
                var err = Backbone.Validation.validators.required(val, attr, this);
                if (typeof err != 'undefined') {
                    this._isValid = false;
                    return err;
                }

                var err = Backbone.Validation.validators.minLength(val, attr, 2, this);
                if (typeof err != 'undefined') {
                    this._isValid = false;
                    return err;
                }
            }
            return;
        },
        lastname: function (val, attr, computed) {
            if (!is_business) {
                var err = Backbone.Validation.validators.required(val, attr, this);
                if (typeof err != 'undefined') {
                    this._isValid = false;
                    return err;
                }

                var err = Backbone.Validation.validators.minLength(val, attr, 2, this);
                if (typeof err != 'undefined') {
                    this._isValid = false;
                    return err;
                }
            }
            return;
        },
        email: {
            required: true,
            pattern: 'email',
        },
        phone: function (val, attr, computed) {
            if (!is_business) {
                var err = Backbone.Validation.validators.required(val, attr, this);
                if (typeof err != 'undefined') {
                    this._isValid = false;
                    return err;
                }
            }
            return;
        },
        street: {
            required: true,
        },
        zipcode: {
            required: true,
            pattern:'digits',
        },
        city: {
            required: true,
        },
        personnumber: function (val, attr, computed) {
            if (jQuery('.recurring').length > 0) {
                var err = Backbone.Validation.validators.required(val, attr, this);
                if (typeof err != 'undefined') {
                    this._isValid = false;
                    return err;
                }
            }

            if (typeof val != 'undefined' && val.length > 0) {
                val = val.replace('-', '');
                var err = Backbone.Validation.validators.minLength(val, attr, 12, this);
                if (typeof err != 'undefined') {
                    this._isValid = false;
                    return err;
                }
            }
            return;
        },
        bankname: function (val, attr, computed) {
            if (jQuery('.recurring').length > 0) {
                var err = Backbone.Validation.validators.required(val, attr, this);
                if (typeof err != 'undefined') {
                    this._isValid = false;
                    return err;
                }
            }
            return;
        },
        clearingnumber: function (val, attr, computed) {
            if (jQuery('.recurring').length > 0) {
                var err = Backbone.Validation.validators.required(val, attr, this);
                if (typeof err != 'undefined') {
                    this._isValid = false;
                    return err;
                }
            }
            return;
        },
        personaccount: function (val, attr, computed) {
            if (jQuery('.recurring').length > 0) {
                var err = Backbone.Validation.validators.required(val, attr, this);
                if (typeof err != 'undefined') {
                    this._isValid = false;
                    return err;
                }
            }
            return;
        },
    },
    initialize : function(){
    },
    toggle: function() {
        this.save({
            completed: !this.get('completed')
        });
 } });