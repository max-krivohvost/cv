var app = app || {};

app.Amount = Backbone.Model.extend({
    url: "/wp-json/process-donation/neworder/",
    defaults: {
        amount: '',
        amountOption:'',
        giftcheckbox:'',
        campaigns: campaigns,
        paymentType:'',
        selectedCampaign:'',
        selectedCampaignValue:'',
        cert_type: '',
        donation_type: 1,
    },
    validation: {
        selectedCampaignValue: function (val, attr, computed)  {
            var err = Backbone.Validation.validators.required(val, attr, this);
            if (typeof err != 'undefined') {
                this._isValid = false;
                return 'Välj en kampanj';
            }
        },
        cert_type: function (val, attr, computed) {
            if (myTodoRouter.amountModel.attributes.giftcheckbox) {
                var err = Backbone.Validation.validators.required(val, attr, this);
                if (typeof err != 'undefined') {
                    this._isValid = false;
                    return 'Välj en typ av gåva';
                }
            }
        },
        amount: function (val, attr, computed) {
            if (jQuery('#amountCustom').is(':checked')) {
                var err = Backbone.Validation.validators.required(val, attr, this);
                if (typeof err != 'undefined') {
                    this._isValid = false;
                    return 'Skriv en summa';
                }

                err = Backbone.Validation.validators.min(val, attr, 50, this);
                if (typeof err != 'undefined') {
                    this._isValid = false;
                    return 'Minsta belopp som du kan ge är 50 kr';
                }
            }
            return;
        },
        paymentType: {
            required: true
        }
    },
    initialize : function(){

        if(typeof(donation_amount) != "undefined"){
            this.set('amount', donation_amount);
        }

        if (is_business) {
            this.set('donation_type', 4);
        }

    },
    initialProcessPayment: function(view){

        jQuery.extend(myTodoRouter.checkoutModel.attributes, myTodoRouter.amountModel.toJSON());
        jQuery.extend(myTodoRouter.checkoutModel.attributes, myTodoRouter.kontaktinfoModel.toJSON());

        if(myTodoRouter.amountModel.attributes.giftcheckbox === true){
            jQuery.extend(myTodoRouter.checkoutModel.attributes, myTodoRouter.giftModel.toJSON());
        }

        if(myTodoRouter.kontaktinfoModel.attributes.goanonym !== true ||
           myTodoRouter.amountModel.attributes.giftcheckbox === true){
            var current_next = view.nextStep();
        }else{
            current_next =  true;
        }

        if(myTodoRouter.checkoutModel.attributes.amount === ''){
            myTodoRouter.checkoutModel.set('amount',myTodoRouter.checkoutModel.attributes.amountOption);
        }

        var email =  myTodoRouter.kontaktinfoModel.attributes.email;
        if(myTodoRouter.kontaktinfoModel.attributes.goanonym === true){
            email = 'info@pmu.se';
            jQuery.extend(myTodoRouter.checkoutModel.attributes,
                {firstname: '', lastname: '', city: '', street: ''});
        }

        myTodoRouter.checkoutModel.save(null, {
            success: function (model, response) {

                if(jQuery('.recurring').length > 0){

                }else{
                    if(current_next === true ) {
                        var method = 'cc.babs';

                        if(typeof(myTodoRouter.kontaktinfoModel.attributes.bankDibs) != "undefined"){
                             method = myTodoRouter.kontaktinfoModel.attributes.bankDibs;
                        }

                        var amount = myTodoRouter.amountModel.getAmount();
                        if (myTodoRouter.giftModel.attributes.sendOption == 'send') {
                            amount = amount * 1 + 30 * 100;
                        }

                        var url = 'https://secure.incab.se/verify/bin/pmu/index';
                        var form = jQuery('<form action="' + url + '" method="post">' +
                            '<input type="hidden" name="currency" value="SEK" />' +
                            '<input type="hidden" name="billingFirstName" value="' +
                            myTodoRouter.checkoutModel.attributes.firstname + '" />' +
                            '<input type="hidden" name="billingLastName" value="' +
                            myTodoRouter.checkoutModel.attributes.lastname + '" />' +
                            '<input type="hidden" name="billingAddress" value="' +
                            myTodoRouter.checkoutModel.attributes.street + '" />' +
                            '<input type="hidden" name="billingCity" value="' +
                            myTodoRouter.checkoutModel.attributes.city + '" />' +
                            '<input type="hidden" name="billingCountry" value="Sweden" />' +
                            '<input type="hidden" name="method" value="'+method+'" />' +
                            '<input type="hidden" name="eMail" value="' +
                            email + '" />' +
                            '<input type="hidden" name="pageSet" value="' +
                            myTodoRouter.amountModel.attributes.paymentType + '" />' +
                            '<input type="hidden" name="purchaseOid" value="' +
                            response.database_id + '" />' +
                            // '<input type="hidden" name="customerOKURL" value="https://pmu.work/geengava/">'+
                                //'<input type="hidden" name="method" value="direct.fsb" />' +
                            '<input type="hidden" name="data" value="1:PMUGiftshop:1:' +
                            amount + ':" />' +'</form>');
                        jQuery('body').append(form);
                        form.submit();
                    }

                }


            },
            error: function (model, response) {

            }
        });
    },
    getAmount: function(){
        var amount = 0;

        if(this.attributes.amount > 0 && this.attributes.amountOption === 'custom'){
            amount = this.attributes.amount*100;
        }else{
            amount = this.attributes.amountOption*100;
        }

        return amount;
    },
    toggle: function() {

    } });


app.CheckoutModel = Backbone.Model.extend({
    url: "/wp-json/process-donation/neworder/",
});
