var app = app || {};

app.StepsView = Backbone.View.extend({
    el: '#donation-steps',
    events: {
        'click .checkout':function(event){
            event.preventDefault ? event.preventDefault() : (event.returnValue = false);
        },
        'click .information':function(event){
            if( Backbone.history.getFragment() === 'giftpage' || Backbone.history.getFragment() === 'amount' &&
                myTodoRouter.amountModel.isValid(true) === true){
            }else{
                event.preventDefault ? event.preventDefault() : (event.returnValue = false);
            }
        },
        'click .giftstep':function(event){
            Backbone.Validation.bind(new app.KontaktView({model:myTodoRouter.kontaktinfoModel}));
            if(  myTodoRouter.kontaktinfoModel.isValid(true) === true ||
                 myTodoRouter.kontaktinfoModel.attributes.goanonym === true){
            }else{
                event.preventDefault ? event.preventDefault() : (event.returnValue = false);
            }
        }
    },
    initialize : function(){
    },
    renderBasic: function(event) {

        this.$el.html('' +
            '<li><a class="amount" href="#amount">Summa</a></li>'+
            '<li><a class="information" href="#kontaktinfo">Kontaktinfo</a></li>'+
            '<li><a class="checkout" href="#checkout">Betalning</a></li>');
        this.$el.removeClass('donation-second');
        jQuery('a[href$="amount"]').parent( "li" ).addClass('donation-current-step');
        return this;
    },
    renderAdvanced: function(event) {

        this.$el.html('' +
            '<li><a class="amount" href="#amount">Summa</a></li>'+
            '<li><a class="information" href="#kontaktinfo">Kontaktinfo</a></li>'+
            '<li><a class="giftstep" href="#giftpage">Gåvobevis</a></li>'+
            '<li><a class="checkout" href="#checkout">Betalning</a></li>');
        this.$el.addClass('donation-second');
        jQuery('a[href$="amount"]').parent( "li" ).addClass('donation-current-step');
        return this;
    },
});
