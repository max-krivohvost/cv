<?php
/**
 * Plugin Name: PMU Donation Form
 * Plugin URI: http://gofervent.com
 * Description: Donation Form for PMU
 * Version: 1.0.0
 * Author: FERVENT
 * Author URI: http://gofervent.com
 * License: GPL2
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

include_once "assently/vendor/autoload.php";

use Assently\Assently;
define('DONATION_ANTICACHE_VERSION', '1.0.3');

class PMU_Donation_Form
{
    private static $security_key = 'xYBeit6e82jpH5nRGT2aMz5vD3fsxlEv';

    public static function get_security_key() {
        return self::$security_key;
    }

    private static function get_kommed_image_id($image_url)
    {
        $image_ids = [
            'Blomknopp_567x341.jpg' => 1,
            'Jasmin_IMG_6681_567x341.jpg' => 2,
            'IMG_4274-syriska-flyktingar-Libanon-567x341.jpg' => 3,
            'NAB1443-567x341.jpg' => 4,
            'NEPAL_DSC09735-Central-och-sydasien-567x341.jpg' => 5,
            'DSC_9630-Kongo-L.-Klingsbo-567x341.jpg' => 6,
        ];

        $response = 1;
        foreach ($image_ids as $img => $id) {
            if (strpos($image_url, $img) !== false) {
	            $response = $id;
            }
        }

        return $response;
    }

	public static function dibs_callback()
	{
		if (!empty($_POST['oid'])) {
			file_put_contents(  get_stylesheet_directory() . '/gegava_dibs_callback.txt',
                str_pad('--- [' . date('Y-m-d H:i:s') . '] ', 100, '-') . "\n"
                . print_r($_POST, 1), FILE_APPEND);

			global $wpdb;
			$order_info = $wpdb->get_row("
                    SELECT * FROM " . $wpdb->prefix . "pmu_entries
                    WHERE id = " . $_REQUEST['oid']);

			if (!empty($_REQUEST['reply']) && $order_info->status == 'pending') { // If successfully payment
				$status = $_REQUEST['reply'] == 'A' ? 'completed' : 'failed';

                $wpdb->query( "
                    UPDATE " . $wpdb->prefix . "pmu_entries
                    SET status = '{$status}'
                    WHERE id = " . $_REQUEST['oid'] );

				if ( $_REQUEST['reply'] == 'A') {

					$campaign_info = $wpdb->get_row( "
                        SELECT * FROM " . $wpdb->prefix . "pmu_campaigns
                        WHERE id = " . $order_info->selectedCampaign );

					$subject = 'Bekräftelse på gåva till PMU';
					if ( ! empty( $order_info->pdf_url ) && ( empty( $order_info->sendOption ) || $order_info->sendOption == 'nosend' ) ) {
						$subject = 'Gåvobevis från PMU';
					}

					$message_body = self::pmu_donation_prepare_email( $order_info, $campaign_info );

					if ( $order_info->status != 'completed' ) {
						self::send_kommed( $order_info, $campaign_info );

						$is_anonymous = empty( $order_info->email );

						global $woocommerce;

						if ( $woocommerce && is_object( $woocommerce ) ) {
							$mailer  = $woocommerce->mailer();
							$message = $mailer->wrap_message( __( 'Stort tack för din gåva!', 'pmu_donation' ), $message_body );

							if ( ! $is_anonymous ) {
								$mailer->send( $order_info->email, $subject, $message );
							}

							if ( in_array( $order_info->donation_type, [ 1, 2, 3, 4 ] ) ) {
								self::pmu_send_admin_email( $mailer, $order_info, $campaign_info );
							}
						};
					}
				}
			}
		}

		ob_end_clean();
		header("HTTP/1.1 200 OK");
		die('VerifyEasy_response:_OK');

	}

    public static function getCampaignInfo($order_info)
    {
        global $wpdb;

        $wpdb->pmu_recurring_campaigns = $wpdb->prefix . 'pmu_recurring_campaigns';

        $campaign_info = $wpdb->get_row("
            SELECT id, title, k_id FROM " . $wpdb->pmu_recurring_campaigns . "
            WHERE id = " . $order_info->selectedCampaign);

        return $campaign_info;
    }

    public static function render_donation_form($atts)
    {
        global $wpdb;
        $wpdb->pmu_recurring_campaigns = $wpdb->prefix . 'pmu_recurring_campaigns';

        if (!empty($_REQUEST['dibs_reply']) && $_REQUEST['dibs_reply'] == 'D') {
	        $order_info = $wpdb->get_row("
                    SELECT * FROM " . $wpdb->prefix . "pmu_entries
                    WHERE id = " . $_REQUEST['input_purchaseOid']);

	        if ($order_info->status == 'pending') {
		        $wpdb->query( "
                    UPDATE " . $wpdb->prefix . "pmu_entries
                    SET status = 'failed'
                    WHERE id = " . $_REQUEST['input_purchaseOid'] );
	        }

            ob_start();
            $thank_you = '<h3>Din betalning misslyckades.</h3>';
            echo "<script>window.history.pushState({}, 'Success', '//{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}?success=0')</script>";
        } else if (!empty($_REQUEST['dibs_reply']) && $_REQUEST['dibs_reply'] == 'A') {

            $order_info = $wpdb->get_row("
                    SELECT * FROM " . $wpdb->prefix . "pmu_entries
                    WHERE id = " . $_REQUEST['input_purchaseOid']);

	        if ($order_info->status == 'pending') {

                $wpdb->query("
                        UPDATE " . $wpdb->prefix . "pmu_entries
                        SET status = 'completed'
                        WHERE id = " . $_REQUEST['input_purchaseOid'] );

                $campaign_info = $wpdb->get_row("
                        SELECT * FROM " . $wpdb->prefix . "pmu_campaigns
                        WHERE id = " . $order_info->selectedCampaign);

                $value = $order_info->amount;

            ?>
                <!-- Enhanced e-commerce -->
                <script type="text/javascript" >
                    ga("require", "ec");
                    ga('set', '&cu', 'SEK');
                    ga('ec:addProduct', {
                        'id': '<?php echo $campaign_info->id; ?>',
                        'name': '<?php echo $campaign_info->title; ?>',
                        'price': '<?php echo $order_info->amount; ?>',
                        'quantity': 1
                    });

                    ga('ec:setAction', 'purchase', {
                        'id': '<?php echo $order_info->id; ?>',
                        'affiliation': 'PMU - Donation form'
                    });

                    ga("send", "event", "Enhanced-Ecommerce","load", "order_confirmation", {"nonInteraction": 1});
                </script>


                <!-- Google Code for PMU Adwords Conversion Page -->
                <script type="text/javascript">
                    /* <![CDATA[ */
                    var google_conversion_id = 867362255;
                    var google_conversion_language = "en";
                    var google_conversion_format = "3";
                    var google_conversion_color = "ffffff";
                    var google_conversion_label = "EniCCJ7Nj2wQz8vLnQM";
                    var google_conversion_value = <?php echo $value; ?>;
                    var google_conversion_currency = "SEK";
                    var google_remarketing_only = false;
                    /* ]]> */
                </script>
                <script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
                </script>
                <noscript>
                    <div style="display:inline;">
                        <img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/867362255/?value=<?php echo $value; ?>&amp;currency_code=SEK&amp;label=EniCCJ7Nj2wQz8vLnQM&amp;guid=ON&amp;script=0"/>
                    </div>
                </noscript>

            <?php

            }

            ob_start();

            echo "<script>window.history.pushState({}, 'Success', '//{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}?success=1')</script>";

            $thank_you = '<div class="thank-you-page"><h3>TACK FÖR DIN GÅVA!</h3>';
            $thank_you .= '<div class="donation-info">Din betalning har gått igenom. </div>';
            $thank_you .= '<div class="thank-you-page-info donation-info">'
                . '<strong>Summa:</strong> ' . $order_info->amount . ' kr.<br>'
                . '<strong>Ändamål:</strong> ' . $campaign_info->title . ''
                . '<div class="ref-summer"><strong>Referensnummer:</strong> ' . $order_info->id . '</div>'
                . '</div>';
            $thank_you .= '<div class="contact-info">Har du frågor, kontakta Givarservice på 08-608 96 00 eller info@pmu.se.</div>';


            $subject = 'Bekräftelse på gåva till PMU';
            if (!empty($order_info->pdf_url) && (empty($order_info->sendOption) || $order_info->sendOption == 'nosend')) {
                $thank_you .= '<div class="succes-pdf">
                             <div class="pdf-text">Klicka på länken för att ladda ner ditt gåvobevis i PDF format</div>
                             <div><a href="/certificate/?code=' . base64_encode($_REQUEST['input_purchaseOid']) . '&option=donation">PMU_D' . $campaign_info->id . '' . dechex($order_info->id) . '.pdf</a></div>
                           </div>';
                $subject = 'Gåvobevis från PMU';

            } elseif (in_array($order_info->donation_type, [2,3])) {
                $thank_you .= '<div class="succes-pdf">
                             <div class="pdf-text">Vi skickar ditt gåvobevis på posten! Det tar 3-4 arbetsdagar. Nedan kan du se ditt gåvobevis.</div>
                           </div>';
            }

            $thank_you .= '</div>';

            $message_body = self::pmu_donation_prepare_email($order_info, $campaign_info);

            if ($order_info->status != 'completed') {
                self::send_kommed($order_info, $campaign_info);

                $is_anonymous = empty($order_info->email);

                global $woocommerce;

                if($woocommerce && is_object($woocommerce)){
                    $mailer = $woocommerce->mailer();
                    $message = $mailer->wrap_message(__('Stort tack för din gåva!','pmu_donation'), $message_body );

                    if (!$is_anonymous) {
                        $mailer->send($order_info->email, $subject, $message);
                    }

                    if (in_array($order_info->donation_type, [1, 2, 3, 4])) {
                        self::pmu_send_admin_email($mailer, $order_info, $campaign_info);
                    }
                };
            }


        } elseif (!empty($_REQUEST['code'])) {

            ob_start();
            $order_info = $wpdb->get_row("
                    SELECT * FROM " . $wpdb->prefix . "pmu_entries
                    WHERE MD5(id) = '" . $_REQUEST['code'] . "'");

            if (!empty($order_info) && $order_info->donation_type == 5) {
                $campaign_info = self::getCampaignInfo($order_info);
                $campaignName = $campaign_info->title;

                $thank_you = '<div class="thank-you-page">';
                $thank_you .= '<div class="donation-info">Tack för att du har bestämt dig att för att bli en del av '
                    . $campaignName . ' – din gåva är värdefull!</div>';
                $thank_you .= '<div class="thank-you-page-info donation-info">'
                    . '</div>';
                $thank_you .= '<div class="contact-info">Har du frågor, kontakta Givarservice på 08-608 96 00 eller info@pmu.se.</div>';


                $subject = 'Tack för att du valt att bli månadsgivare hos PMU!';
                if ($order_info->sendOption == 'nosend') {
                    $thank_you .= '<div class="succes-pdf">
                             <div class="pdf-text">Beroende på om du valt att få en blankett hemskickad eller vill 
                             skriva ut den själv så kommer du få ett brev eller mejl (du kan också klicka på länken nedan) 
                             - skriv under och skicka in så börjar dina pengar snart rädda liv!</div>
                             <div>
                             <a href="/certificate2/?code=' . md5($order_info->id) . '">PMU_D' . $order_info->selectedCampaign . '' . dechex($order_info->id) . '.pdf</a></div>
                           </div>';
                } else {
                    $thank_you .= '<div class="succes-pdf">
                             <div class="pdf-text">Vi skickar ditt gåvobevis på posten! Det tar 3-4 arbetsdagar. Nedan kan du se ditt gåvobevis.</div>
                           </div>';
                }

                $thank_you .= '</div>';

                if ($order_info->donation_type == 5) {
                    $message_body = self::pmu_recurring_prepare_email($order_info, $campaignName);
                }

                if ($order_info->status != 'completed') {
                    global $woocommerce;

                    $is_anonymous = empty($order_info->email);

                    self::send_kommed($order_info, $campaign_info);

                    if($woocommerce && is_object($woocommerce)){
                        $mailer = $woocommerce->mailer();
                        $message = $mailer->wrap_message(__('Tack för att du valt att bli månadsgivare hos PMU!','pmu_donation'), $message_body );

                        if (!$is_anonymous) {
                            $mailer->send( $order_info->email, $subject, $message );
                        }

                        self::pmu_send_admin_email($mailer, $order_info, $campaignName);
                    };

                    $wpdb->query("UPDATE " . $wpdb->prefix . "pmu_entries
                        SET status = 'completed'
                        WHERE MD5(id) = '" . $_REQUEST['code'] . "'");

                }
            }
        } elseif (!empty($_REQUEST['assently_status']) && $_REQUEST['assently_status'] == 'success') {
            ob_start();
            $thank_you = '<div class="thank-you-page">';
            $thank_you .= '<div class="donation-info">Tack för att du valt att bli månadsgivare! Din hjälp är otroligt värdefull! </div>';
            $thank_you .= '<div class="thank-you-page-info donation-info">'
                . '</div>';
            $thank_you .= '<div class="contact-info">Har du frågor, kontakta Givarservice på 08-608 96 00 eller info@pmu.se.</div>';
            $thank_you .= '</div>';
        } elseif (!empty($_REQUEST['assently_callback'])) {

            $data = file_get_contents('php://input');
            $data = json_decode($data);
            $document_id = $data->Model->Id;

            $order_info = $wpdb->get_row("SELECT * FROM " . $wpdb->prefix . "pmu_entries
                    WHERE assently_doc_id = '" . $document_id . "'");

//            file_put_contents('assently_test.txt', print_r($order_info, 1) . "\n", FILE_APPEND);

            if (!empty($order_info)) {
                $campaign_info = self::getCampaignInfo($order_info);

                $campaignName = $campaign_info->title;

                self::send_kommed($order_info, $campaign_info);

                global $woocommerce;

                if($woocommerce && is_object($woocommerce)){
                    $mailer = $woocommerce->mailer();

                    self::pmu_send_admin_email($mailer, $order_info, $campaignName);
                };
            }

            die();
        } else {
            ob_start();
        }

        switch ($url = $_SERVER['REQUEST_URI']) {
            case (strpos($url, 'pmu-companies') !== false):
                $page = 'companies';
                break;
            case (strpos($url, 'manadsgivare') !== false):
                $page = 'recurring';
                break;
            default:
                $page = 'gegava';
        }

        $class_rec = '';
        if (!empty($atts['recurring']) && $atts['recurring'] == 'true' ):
            $class_rec = "recurring";
        endif;

        if (!empty($atts['international']) && $atts['international'] == 'true'):
            $class_rec .= "international";
        endif;

        ?>


        <div class="donation-header">

            <h2 style="color:#fff">Ge en gåva</h2>
            <?php if (empty($thank_you) && empty($class_rec) || $atts['international'] != 'true'): ?>

<!--            --><?php //if (empty($atts['business']) || $atts['business'] == 'false'): ?>
<!--                <a class="x-btn x-child-btn white x-btn-square x-btn-small" href="/pmu-companies/">Ge som företag</a>-->
<!--            --><?php //else: ?>
<!--                <a class="x-btn x-child-btn white x-btn-square x-btn-small" href="/gegava/">Ge som privatperson</a>-->
<!--            --><?php //endif; ?>
            <?php endif; ?>
        </div>


        <div class="donation-block <?php if (!empty($class_rec)) echo $class_rec; ?>">
            <?php if (!empty($thank_you)):
                echo $thank_you;
            else: ?>
                <div class="donation-tabs <?php echo (!empty($atts['business']) && $atts['business'] == '@true' ? 'hide-right-tab' : ''); ?>">
                    <div class="<?= (!empty($page) && $page == 'gegava' ? 'selected-tab' : ''); ?> donation-tab donation-left-tab tab-1"
                         data-link="/gegava/">Engångsgåva
                    </div>
                    <div class="<?= (!empty($page) && $page == 'recurring' ? 'selected-tab' : ''); ?> donation-tab donation-left-tab tab-2"
                         data-link="/manadsgivare/">Bli månadsgivare
                    </div>
                    <div class="<?= (!empty($page) && $page == 'companies' ? 'selected-tab' : ''); ?> donation-tab donation-left-tab tab-3"
                         data-link="/pmu-companies/">Ge som företag
                    </div>
                </div>
                <div class="donation-wrapper">
                    <ul id="donation-steps">
                        <li class="donation-current-step"><a class="amount" href="#amount">Summa</a></li>
                        <li><a class="information" href="#kontaktinfo">Kontaktinfo</a></li>
                        <li><a class="checkout" href="#">Betalning</a></li>
                    </ul>
                    <div id="donation-area">
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <?php

        if ($atts['selected_campaign'] == 'all') {
            $campaigns = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "pmu_campaigns ORDER BY `order`");
        } else {
            $campaigns = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "pmu_campaigns WHERE id=" . $atts['selected_campaign']);
        }

        if (empty($atts['recurring_selected_campaign']) || $atts['recurring_selected_campaign'] == 'all') {
            $recurring_campaigns = $wpdb->get_results("SELECT * FROM " . $wpdb->pmu_recurring_campaigns . " ORDER BY `order`");
        } else {
            $recurring_campaigns = $wpdb->get_results("SELECT * FROM " . $wpdb->pmu_recurring_campaigns . " WHERE id=" . $atts['selected_campaign']);
        }

        $campaigns_array = [];
        $selectedClass = '';
        if (empty($atts['selected_campaign']) || $atts['selected_campaign'] == 'all') {
            $selectedClass = ' not-selected';

            $campaigns_array = [
                [
                    'id' => null,
                    'text' => __('-- Select campaign --', '__x__'),
                    'value' => null,
                    'selected' => false,
                    'description' => null,
                    'imageSrc' => null
                ]
            ];
        }

        foreach ($campaigns as $campaign):
            $image_url = wp_get_attachment_image_src($campaign->image_id);

            $campaigns_array[] = [
                'id' => $campaign->id,
                'text' => $campaign->title,
                'value' => $campaign->k_id,
                'selected' => false,
                'description' =>  $campaign->subtitle,
                'imageSrc' => $image_url[0]
            ];
        endforeach;

        unset ($campaign);
        $recurring_campaigns_array = [
            [
                'text' => __('-- Select campaign --', '__x__'),
                'value' => null,
                'imageSrc' => null
            ]
        ];

        foreach ($recurring_campaigns as $campaign):
            $recurring_campaigns_array[] = [
                'text' => $campaign->title,
                'value' => $campaign->id,
                'imageSrc' => ''
            ];
        endforeach;

        ?>
        <script type="text/javascript">
            var is_business = <?php echo (!empty($atts['business']) && $atts['business'] == 'true' ? 'true' : 'false'); ?>;
            var campaigns = <?php echo json_encode($campaigns_array); ?>;
            var recurring_campaigns = <?php echo json_encode($recurring_campaigns_array); ?>;
            <?php if(!empty($_POST['x-amount'])):?>
            var donation_amount = <?php echo $_POST['x-amount']; ?>;
            <?php endif; ?>
        </script>

        <script id="amount-template" type="text/x-handlebars-template">
            <form class="amount-form">
                <div class="donation-amount-block">
                    <input id="amount100" type="radio" name="amountOption" class="amountOption" value="100">
                    <label for="amount100">100 kr</label>
                    <input id="amount200" type="radio" name="amountOption" class="amountOption"
                        <?php if (empty($_POST['x-amount'])): echo 'checked="checked"'; endif; ?>
                           value="200">
                    <label for="amount200">200 kr</label>
                    <input id="amount500" type="radio" name="amountOption" class="amountOption" value="500">
                    <label for="amount500">500 kr</label>
                    <input id="amountCustom" type="radio" name="amountOption" class="amountOption" value="custom"
                        <?php if (!empty($_POST['x-amount'])): echo 'checked="checked"'; endif; ?> >
                    <label for="amountCustom">Valfri summa</label>
                </div>
                <input disabled name="amount" placeholder="Valfri summa" class="donation-amount" value="{{amount}}">
                <div class="gift-error-wrapper">
                    <div class="error-message-donation">{{validation_message}}</div>
                </div>
                <span class="help-block hidden"></span>
                <select id="donation-campaign" class="donation-campaign<?= $selectedClass ;?>">
                    {{#each campaigns}}
                    <!--                                    <option value="{{value}}" {{isSelected selected}}>{{title}}</option>-->
                    {{/each}}
                </select>
                <div class="gift-error-wrapper">
                    <div class="error-message-donation-campaign">{{validation_message}}</div>
                </div>
                <div class="gift-step">
                    <input id="gitt-checkbox" name="gift-checkbox" class="gift-checkbox" type="checkbox" value="on">
                    <label for="gitt-checkbox">Ge som minnes - eller gratulationsgåva</label>
                    <div class="cert-type hidden">
                        <input type="radio" id="cert_type_gift" name="cert_type" value="gift">
                        <label for="cert_type_gift">Gratulationsgåva</label>
                        <input type="radio" id="cert_type_funeral" name="cert_type" value="funeral">
                        <label for="cert_type_funeral">Minnesgåvor</label>
                    </div>
                </div>
                <div class="gift-error-wrapper">
                    <div class="error-message-donation-2">{{validation_message}}</div>
                </div>

<!--                --><?php //if (!empty($atts['business']) && $atts['business'] != 'true'): ?>
<!--                    <div class="system-message">-->
<!--                        Sista dag för garanterad hemleverens innan jul är 20 dec! Men det går alltid bra att välja att skriva ut själv.-->
<!--                    </div>-->
<!--                --><?php //endif; ?>

                <div class="donation-right-button">
                    <span class="donation-button-title">Ge med betalkort</span>
                    <span class="donation-button-subtitle">VISA, MasterCard, Maestro & AMEX</span>
                </div>
                <div class="donation-left-button">
                    <span class="donation-button-title">Ge med internetbank</span>
                    <span class="donation-button-subtitle">Swedbank,SEB,Handelsbanken</span>
                </div>

            </form>
        </script>

        <script id="amount-template-for-business" type="text/x-handlebars-template">
            <form class="amount-form">
                <div class="donation-amount-block">
                    <input id="amount1000" type="radio" name="amountOption" class="amountOption" value="1000">
                    <label for="amount1000">1000 kr</label>
                    <input id="amount5000" type="radio" name="amountOption" class="amountOption"
                        <?php if (empty($_POST['x-amount'])): echo 'checked="checked"'; endif; ?>
                           value="5000">
                    <label for="amount5000">5000 kr</label>
                    <input id="amount10000" type="radio" name="amountOption" class="amountOption" value="10000">
                    <label for="amount10000">10000 kr</label>
                    <input id="amountCustom" type="radio" name="amountOption" class="amountOption" value="custom"
                        <?php if (!empty($_POST['x-amount'])): echo 'checked="checked"'; endif; ?> >
                    <label for="amountCustom">Valfri summa</label>
                </div>
                <input disabled name="amount" placeholder="Valfri summa" class="donation-amount" value="{{amount}}">
                <div class="gift-error-wrapper">
                    <div class="error-message-donation">{{validation_message}}</div>
                </div>
                <span class="help-block hidden"></span>
                <select id="donation-campaign" class="donation-campaign <?= $selectedClass ;?>">
                    {{#each campaigns}}
                    <!--                                    <option value="{{value}}" {{isSelected selected}}>{{title}}</option>-->
                    {{/each}}
                </select>
                <div class="gift-error-wrapper">
                    <div class="error-message-donation-campaign">{{validation_message}}</div>
                </div>
                <div class="gift-step">
                    <input id="gitt-checkbox" name="gift-checkbox" class="gift-checkbox" type="checkbox" value="on">
                    <label for="gitt-checkbox">Ge som minnes - eller gratulationsgåva</label>
                    <div class="cert-type hidden">
                        <input type="radio" id="cert_type_gift" name="cert_type" value="gift">
                        <label for="cert_type_gift">Gratulationsgåva</label>
                        <input type="radio" id="cert_type_funeral" name="cert_type" value="funeral">
                        <label for="cert_type_funeral">Minnesgåvor</label>
                    </div>
                </div>
                <div class="gift-error-wrapper">
                    <div class="error-message-donation-2">{{validation_message}}</div>
                </div>

                <!--                --><?php //if (!empty($atts['business']) && $atts['business'] != 'true'): ?>
                <!--                    <div class="system-message">-->
                <!--                        Sista dag för garanterad hemleverens innan jul är 20 dec! Men det går alltid bra att välja att skriva ut själv.-->
                <!--                    </div>-->
                <!--                --><?php //endif; ?>

                <div class="donation-right-button">
                    <span class="donation-button-title">Ge med betalkort</span>
                    <span class="donation-button-subtitle">VISA, MasterCard, Maestro & AMEX</span>
                </div>
                <div class="donation-left-button">
                    <span class="donation-button-title">Ge med internetbank</span>
                    <span class="donation-button-subtitle">Swedbank,SEB,Handelsbanken</span>
                </div>

            </form>
        </script>


        <script id="gift-template" type="text/x-handlebars-template">
            <form class="donation-gift-form">
                <div class="donation-gift-mobile">
                    <div class="donation-gift-images">
                        <?php
                        foreach (self::get_images() as $image):
                            echo '<div style="background-image:url(' . $image . ') " class="donation-gift-previewitem"></div>';
                        endforeach;
                        ?>
                    </div>
                </div>
                <div class="donation-gift-right">
                    <label class="image-block-label">Välj motiv</label>
                    <div class="donation-gift-images">
                        <?php
                        foreach (self::get_images() as $image):
                            echo '<div style="background-image:url(' . $image . ') " class="donation-gift-previewitem"></div>';
                        endforeach;
                        ?>
                    </div>
                </div>
                <div class="donation-gift-left">
                    <div class="donation-gift-preview"></div>
                    <div>
                        <div class="headline hidden"></div>
                        <input data-limit-chars="true" data-chars="60" maxlength="60" name="headline" value="{{headline}}" placeholder="Namnet på den du vill gratulera" type="text">
                    </div>
                    <div>
                        <input data-limit-chars="true" data-chars="60" maxlength="60" name="name_deceased" value="{{name_deceased}}" placeholder="Namnet på den avlidne" type="text">
                    </div>
                    <div>
                        <textarea  data-limit-rows="true" data-limit-chars="true" data-chars="300" rows="4"  maxlength="300" name="greeting" value="{{greeting}}" placeholder="Hälsning"></textarea>
                    </div>
                    <div class="donation-gift-wrapper">
                        <!--                        <p class="donation-gift-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit.Suspendisse eu ullamcorper urna.</p>-->
                    </div>
                </div>
                <div class="donation-gift-options">
                    <input id="sendOptionYes" type="radio" class="sendOption" name="sendOption" value="nosend" checked>
                    <label for="sendOptionYes"> Jag skriver ut själv</label> <br/>
                    <input id="sendOptionNo" type="radio" class="sendOption" name="sendOption" value="send">
                    <label for="sendOptionNo"> Jag vill få hemskickat (30 kr för porto tillkommer)</label> <br/>
                </div>
                <div class="donation-gift-address">
                    <div class="donation-gift-title"> Adress den ska skickas till</div>
                    <input name="name_gift" value="{{name}}" placeholder="Namn*
" type="text">
                    <input name="street_gift" value="{{street}}" placeholder="Adress*" type="text">
                    <input name="zipcode_gift" value="{{zipcode}}" placeholder="Postnummer*" type="text">
                    <input name="city_gift" value="{{city}}" placeholder="Stad*" type="text">
                    <input name="deceaseds_name" value="{{deceaseds_name}}" placeholder="Den avlidnes namn*" type="text">
                    <input class="arrivaldate" name="arrivaldate" value="{{arrivaldate}}" placeholder="Önskat leverensdatum"
                           type="text" readonly="readonly">
                    <div class="donation-anonymous">
                        <input id="useAddress" type="checkbox" name="donationContact" value="useAddress" class="donationContact">
                        <label for="useAddress">Använd min kontaktadress.</label>
                    </div>
                </div>
                <div style="text-align: center;">
                    <div class="gift-error-wrapper">
                        <div class="error-message-donation">Fälten är obligatoriska.</div>
                    </div>
                    <div class="donation-button preview-button">
                        <span class="donation-button-title">Förhandsvisning</span>
                    </div>
                    <div class="donation-gonext donation-button">
                        <span class="donation-button-title">Ge din gåva!</span>
                    </div>
                    <div class="process hidden">
                        <i class="fa fa-spinner faa-spin animated" aria-hidden="true"></i>
                    </div>
                </div>
            </form>
        </script>

        <script id="kontaktinfo-template" type="text/x-handlebars-template">
            <form class="donation-information">
                <div class="donation-information-block">
                    <div class="personal-number-wrapper">
                        <label>Personnummer</label>
                        <input class="person-number" name="personnumber" placeholder="ÅÅÅÅMMDD-XXXX" value="{{personnumber}}">
                        <span class="help-block hidden"></span>

                        <button class="get-address">Hämta adress</button>

                        <div class="process-get-address hidden">
                            <div class="process-wrapper">
                            <i class="fa fa-spinner fa-spin fa-3x fa-fw"></i>
                            </div>
                        </div>
                        <hr class="after-person-number">
                    </div>
                    <input name="company" placeholder="Företag*" value="{{company}}">
                    <span class="help-block hidden"></span>
                    <input name="organisation_number" placeholder="Organisationsnummer*" value="{{organisation_number}}">
                    <span class="help-block hidden"></span>
                    <input name="contact" placeholder="Kontaktperson*" value="{{contact}}">
                    <span class="help-block hidden"></span>

                    <input name="firstname" placeholder="Förnamn*" value="{{firstname}}">
                    <span class="help-block hidden"></span>
                    <input name="lastname" placeholder="Efternamn*" value="{{lastname}}">
                    <span class="help-block hidden"></span>
                    <input name="email" placeholder="E-postadress*" value="{{email}}">
                    <span class="help-block hidden"></span>
                    <input name="phone" placeholder="Mobiletelefon*" value="{{phone}}">
                    <span class="help-block hidden"></span>
                    <input class="donation-street" name="street" style="width:507px;" placeholder="Adress*" value="{{street}}">
                    <span class="help-block hidden"></span>
                    <input name="zipcode" placeholder="Postnummer*" value="{{zipcode}}">
                    <span class="help-block hidden"></span>
                    <input class="donation-city" name="city" placeholder="Stad*" value="{{city}}">
                    <span class="help-block hidden"></span>

                    <div class="recurring-fields">

                        <input class="bank-name" name="bankname" placeholder="Bankens namn*" value="{{bankname}}" maxlength="45">
                        <span class="help-block hidden"></span>
                        <input class="clearing-number" name="clearingnumber" placeholder="Clearingnummer*" value="{{clearingnumber}}">
                        <span class="help-block hidden"></span>
                        <input class="person-account" name="personaccount" placeholder="Bankkonto/Personkonto*" value="{{personaccount}}">
                        <span class="help-block hidden"></span>
                    </div>

                    <div class="error-message-donation">Fälten är obligatoriska.</div>
                </div>

                <div class="donation-anonymous">
                    <input id="goanonym" name="goanonym" class="goanonym" type="checkbox">
                    <label for="goanonym">Jag vill vara anonym</label>
                </div>
                <div style="display: none" class="donation-bank">
                    <ul>
                        <li><input id="Swedbank" type="radio" class="bankDibs" name="bankDibs" value="direct.fsb">
                            <label for="Swedbank">Swedbank</label>
                        </li>
                        <li><input id="Nordea"  type="radio" class="bankDibs" name="bankDibs" value="direct.nb">
                            <label for="Nordea">Nordea</label>
                        </li>
                        <li><input id="SEB" type="radio" class="bankDibs" name="bankDibs" value="direct.sebp">
                            <label for="SEB">SEB</label>
                        </li>
                        <li><input id="Handelsbanken" type="radio" class="bankDibs" name="bankDibs" value="direct.shb">
                            <label for="Handelsbanken">Handelsbanken</label>
                        </li>
                    </ul>
                </div>

                <div style="display:none;" class="bottom-radio">
                    <div class="handle-message">Vi hanterar era uppgifter i enlighet med PUL</div>
                    <input id="assently" type="radio" name="deliveryOption" class="deliveryOption" value="assently">
                    <label for="assently">Signera direkt med bankID</label>
                    <input id="deliveryYes" type="radio" name="deliveryOption" class="deliveryOption" checked="checked" value="yes">
                    <label for="deliveryYes">Skicka blankett om autogiromedgivande hem till mig</label>
                    <input id="deliveryNo" type="radio" name="deliveryOption" class="deliveryOption" value="no">
                    <label for="deliveryNo">Jag skriver ut själv</label>
                </div>
            </form>
            <div style="text-align: center; width: 100%; display: inline-block;">
                <div class="process hidden">
                    <div class="additional-message hidden">
                        OBS: Det kan ta uppemot 30 sekunder innan du blir ansluten till e-signeringen. Stäng inte ner din webbläsare.
                    </div>
                    <i class="fa fa-spinner faa-spin animated" aria-hidden="true"></i>
                </div>
            </div>
            <div class="donation-godibs donation-button">
                <span class="donation-button-title">{{kontaktbutton}}</span>
            </div>
        </script>


        <script id="recurring-template" type="text/x-handlebars-template">

            <form class="reccuring-form">
                <div class="donation-amount-block">
                    <div class="">
                        <h5>Jag vill ge varje månad:</h5>
                    </div>
                    <div class="recurring-options">
                        <input id="amount200" type="radio" name="amountOption" class="amountOption"
                            <?php if (empty($_POST['x-amount'])): echo 'checked="checked"'; endif; ?>
                               value="200">
                        <label for="amount200">200 kr</label>

                        <input id="amount300" type="radio" name="amountOption" class="amountOption" value="300">
                        <label for="amount300">300 kr</label>

                        <input id="amount500" type="radio" name="amountOption" class="amountOption" value="500">
                        <label for="amount500">500 kr</label>

                        <input id="amountCustom" type="radio" name="amountOption" class="amountOption" value="custom"
                            <?php if (!empty($_POST['x-amount'])): echo 'checked="checked"'; endif; ?> >
                        <label for="amountCustom">Valfri summa</label>
                    </div>
                </div>
                <input disabled name="amount" placeholder="Valfri summa" class="donation-amount" value="{{amount}}">
                <div class="gift-error-wrapper">
                    <div class="error-message-donation">{{validation_message}}</div>
                </div>
                <select id="attr_giverType" name="attr_giverType" class="optiontogive">
                    <!--                    <option value="20163" selected="true">Månadsgivare till hela PMU:s arbete</option>-->
                    <!--                    <option value="20164">Månadsgivare till PMU:s arbete i Kongo</option>-->
                    <!--                    <option value="20165">Barnens Rätt-vän</option>-->
                </select>
                <div class="gift-error-wrapper">
                    <div class="error-message-donation-campaign">{{validation_message}}</div>
                </div>

            </form>
            <br/>
            <div class="donation-godibs donation-button">
                <span class="donation-button-title">Fortsätt</span>
            </div>
        </script>


        <link rel="stylesheet" href="/wp-content/plugins/pmu-donation/app/styles/main.css?v=<?php echo DONATION_ANTICACHE_VERSION;?>" type="text/css" media="all"/>
        <script src="/wp-content/plugins/pmu-donation/app/js/libs/handlebars/handlebars.js"></script>
        <script src="/wp-content/plugins/pmu-donation/app/js/libs/underscore.js"></script>
        <script src="/wp-content/plugins/pmu-donation/app/js/libs/backbone.js"></script>
        <script src="/wp-content/plugins/pmu-donation/app/js/libs/backbone-validation-min.js"></script>
        <script src="/wp-content/plugins/pmu-donation/app/js/libs/backbone.stickit.js"></script>
        <script src="/wp-content/plugins/pmu-donation/app/js/libs/jquery.ddslick.min.js"></script>
        <script src="/wp-content/plugins/pmu-donation/app/js/models/amount.js?v=<?php echo DONATION_ANTICACHE_VERSION;?>"></script>
        <script src="/wp-content/plugins/pmu-donation/app/js/models/kontaktinfo.js?v=<?php echo DONATION_ANTICACHE_VERSION;?>"></script>
        <script src="/wp-content/plugins/pmu-donation/app/js/models/gift.js?v=<?php echo DONATION_ANTICACHE_VERSION;?>"></script>
        <!--        --><?php //if(!empty($class_rec) && $class_rec == 'recurring'):
        ?>
        <!--        <script src="/wp-content/plugins/pmu-donation/app/js/views/recurringSteps.js"></script>-->
        <!--        --><?php //else:
        ?>
        <script src="/wp-content/plugins/pmu-donation/app/js/views/steps.js?v=<?php echo DONATION_ANTICACHE_VERSION;?>"></script>
        <!--        --><?php //endif;
        ?>
        <script src="/wp-content/plugins/pmu-donation/app/js/app.js?v=<?php echo DONATION_ANTICACHE_VERSION;?>"></script>
        <script src="/wp-content/plugins/pmu-donation/app/js/routes/router.js?v=<?php echo DONATION_ANTICACHE_VERSION;?>"></script>


        <?php
        wp_enqueue_style('x-datepicker', X_TEMPLATE_URL . '/framework/css/dist/admin/datepicker.css', NULL, X_VERSION, 'all');
        wp_enqueue_script('jquery-ui-datepicker');

        return trim(ob_get_clean());
    }

    public static function add_pmu_donation_menu_items()
    {
        global $page_hook_suffix;
//        $page_hook_suffix = add_options_page(__('Preview images', 'pmu_donation'), __('PMU Donation', 'pmu_donation'),
//            'manage_options', 'pmu-donation-settings', [__CLASS__, 'pmu_donation_settings_page']);
//

        $page_hook_suffix = add_menu_page('Gåvor', 'Gåvor', 'manage_options', 'pmu-donation', null, '');
        add_submenu_page('pmu-donation', 'Bilder gåvobevis', 'Bilder gåvobevis', 'manage_options', 'pmu-donation', [__CLASS__, 'pmu_donation_settings_page']);

        add_submenu_page('pmu-donation',
            'Gåvoändamål',
            'Gåvoändamål',
            'manage_options',
            'campaigns_list',
            [__CLASS__, 'pmu_donation_campaignslist']); //function

        add_submenu_page('pmu-donation',
            'Månadsgivare gåvoändamål',
            'Månadsgivare gåvoändamål',
            'manage_options',
            'recurring_campaigns_list',
            [__CLASS__, 'pmu_recurring_campaigns_list']); //function

        add_submenu_page('pmu-donation',
            'Certifikatgenerering',
            'Certifikatgenerering',
            'manage_options',
            'generate_certificate',
            [__CLASS__, 'pmu_generate_certificate']); //function
    }

    public function pmu_generate_certificate()
    {
        global $wpdb;

        $content = <<< HTML
<div class="wrap">
    <h1>Certifikatgenerering</h1>
    <div class="form-wrapper">
        <h3><strong>Välj motiv</strong></h3>
        <div class="certificate-images-wrapper">
            {images}
        </div>
        <div class="fields-wrapper">
            <div class="cert_type">
                <input type="radio" id="gift_cert_type" name="cert_type" value="gift" checked> 
                <label for="gift_cert_type">Gratulationsgåva</label>
                <input type="radio" id="funeral_cert_type" name="cert_type" value="funeral"> 
                <label for="funeral_cert_type">Minnesgåvor</label>
            </div>
            <div>
                <select name="campaign">
                    {campaign_options}
                </select>
            </div>
            <div class="field_name_deceased hidden">
                <input data-limit-chars="true" data-chars="60" maxlength="60" name="name_deceased" value="" 
                placeholder="Namnet på den avlidne" type="text">
            </div>
            <div class="field_headline">
                <input data-limit-chars="true" data-chars="60" maxlength="60" name="headline" value="" 
                placeholder="Namnet på den du vill gratulera" type="text">
            </div>
            <div>
                <textarea data-limit-rows="true" data-limit-chars="true" data-chars="300" rows="4" cols="90" maxlength="300" 
                name="greeting" value="" placeholder="Hälsning"></textarea>
            </div>
        </div>
        
        <div class="action-wrapper">
            <button class="button button-primary" role="generate-cert">Generera</button>
        </div>
    </div>
</div>
HTML;

        $campaign_options = '';
        $campaigns = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "pmu_campaigns ORDER BY `order`");
        foreach ($campaigns as $campaign) {
            $campaign_options .= <<<HTML
<option value="{$campaign->id}">{$campaign->title}</option>
HTML;
        }

        $images = self::get_images();

        $images_html = '';
        foreach ($images as $id => $image) {
            $checked = '';
            if ($id == 0) {
                $checked = 'checked';
            }
            $images_html .= <<< HTML
<div>
    <input type="radio" name="img_url" id="img_$id" value="$image" style="display: none;" $checked>
    <label style="background-image: url($image);" class="donation-gift-previewitem" for="img_$id"></label>
</div>
HTML;
        }

        $replaces = [
            '{images}' => $images_html,
            '{campaign_options}' => $campaign_options,
        ];

        $content = str_replace(array_keys($replaces), array_values($replaces), $content);

        echo $content;
    }


    public static function update_campaigns_order()
    {
        global $wpdb;

        if (!empty($_POST['order'])) {
            foreach ($_POST['order'] as $id => $val) {
                if (empty($val)) {
                    $val = 'NULL';
                }

                $wpdb->query("UPDATE " . $wpdb->prefix . "pmu_campaigns 
                    SET `order` = " . $val . " WHERE id = " . (int) $id);
            }
        }

        die();
    }

    public function pmu_donation_campaignslist()
    {

        global $wpdb;

        if ($_REQUEST['action'] == 'save') {

            $_REQUEST['image'] = explode('|', $_REQUEST['image']);
            $_REQUEST['image'] = $_REQUEST['image'][0];

            $next_order = (int) $wpdb->get_var("SELECT MAX(`order`) FROM " . $wpdb->prefix . "pmu_campaigns");
            $next_order++;

            $wpdb->insert(
                $wpdb->prefix . 'pmu_campaigns',
                array(
                    'title' => $_REQUEST['campaigns_title'],
                    'subtitle' => $_REQUEST['campaigns_subtitle'],
                    'k_id' => $_REQUEST['campaigns_kommedid'],
                    'image_id' => $_REQUEST['image'],
                    'order' => $next_order,
                ),
                array(
                    '%s', '%s', '%s', '%d', '%d',
                )
            );


            echo '<div class="updated notice">
                      <p>Changes successfully saved</p>
                </div>';

        } elseif ($_REQUEST['action'] == 'delete' && !empty($_REQUEST['id'])) {

            $wpdb->query("DELETE FROM " . $wpdb->prefix . "pmu_campaigns
                          WHERE id = '" . $_REQUEST['id'] . "'");

        } elseif ($_REQUEST['action'] == 'update' && !empty($_REQUEST['campaign_id'])) {

            $_REQUEST['image'] = explode('|', $_REQUEST['image']);
            $_REQUEST['image'] = $_REQUEST['image'][0];

            $wpdb->query("
                    UPDATE " . $wpdb->prefix . "pmu_campaigns
                    SET title = '" . $_REQUEST['campaigns_title'] . "',
                    subtitle = '" . $_REQUEST['campaigns_subtitle'] . "',
                    k_id = '" . $_REQUEST['campaigns_kommedid'] . "',
                    image_id = '" . $_REQUEST['image'] . "'
                    WHERE id = " . $_REQUEST['campaign_id'] . "
                    ");

        }


        if ($_REQUEST['action'] == 'add_new' || $_REQUEST['action'] == 'edit') {
            if ($_REQUEST['action'] == 'add_new') {
                $title = 'Skapa nytt';
            } else {
                $title = 'Regidera';
            }

            $form_action = 'save';
            if (!empty($_REQUEST['id'])) {
                $campaign_content = $wpdb->get_row("SELECT * FROM " . $wpdb->prefix . "pmu_campaigns WHERE id = " . $_REQUEST['id']);
                $form_action = 'update';
                $image_url = wp_get_attachment_image_src($campaign_content->image_id);
                $top_image_url = wp_get_attachment_image_src($campaign_content->top_image_id, 'pmu-320');
                if (!empty($campaign_content->image_id)) {
                    $image_class = 'with-img';
                }
            }

            $content = '
           <div class="wrap">
           <h1>' . $title . ' gåvoändamål</h1>
           <form class="campaignslist" method="post" action="admin.php?page=campaigns_list&action=' . $form_action . '">
                <p>
                    <input placeholder="Title" type="text" name="campaigns_title" size="30"
                           value="' . $campaign_content->title . '" id="title" ></p>
                <p>

                   <input type="hidden" name="image" value="' . $campaign_content->image_id . '|' . $image_url[0] . '">
                   <a href="#" class="media-button ' . $image_class . '"><img src="' . $image_url[0] . '" class="hide"></a>
                </p>
                <p>
                    <input placeholder="Subtitle" type="text" name="campaigns_subtitle" size="30"
                           value="' . $campaign_content->subtitle . '" id="title" ></p>
                <p>
                    <input placeholder="Kommed id" type="text" name="campaigns_kommedid" size="30"
                           value="' . $campaign_content->k_id . '" id="title" ></p>
                <input type="hidden" name="campaign_id" value="' . $campaign_content->id . '">
                <input type="submit" class="button button-primary button-large" value="Save">
           </form>
           </div>';

        } else {
            $content = '
           <div class="wrap">
           <h1>Gåvoändamål <a href="admin.php?page=campaigns_list&action=add_new" class="page-title-action">Skapa nytt</a></h1>
               <table class="wp-list-table widefat fixed striped posts">
                   <thead>
                        <th>Title</th>
                        <th>Subtitle</th>
                        <th>Image</th>
                        <th>Kommed id</th>
                        <th>Order</th>
                        <th>Action</th>
                   </thead>
                   <tbody>
                        {results}
                   </tbody>
                   <tfoot></tfoot>
               </table>
               
               <p class="buttons-wrapper">
                    <button name="update-order" role="update-campaigns-order" 
                        class="button button-primary button-large">Uppdateringsorder</button> 
                    <span class="spinner"></span>
               </p>
           </div>';

            $campaigns = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "pmu_campaigns ORDER BY `order`");

            $result_campaign = '';

            foreach ($campaigns as $campaign) {
                $img_thumb = wp_get_attachment_image_src($campaign->image_id, $size = 'thumbnail');
                $result_campaign .= '<tr>
                    <td>' . $campaign->title . '</td>
                    <td>' . $campaign->subtitle . '</td>
                    <td><img   width="80px;" src="' . $img_thumb[0] . '"/></td>
                    <td>' . $campaign->k_id . '</td>
                    <td><input data-id="' . $campaign->id . '" 
                        name="order[' . $campaign->id . ']" value="' . $campaign->order . '" size="5"></td>
                    <td>
                        <a href="admin.php?page=campaigns_list&action=edit&id=' . $campaign->id . '">Regidera</a></br>
                        <a href="admin.php?page=campaigns_list&action=delete&id=' . $campaign->id . '">Radera</a>
                    </td>
                </tr>';
            }
            $content = str_replace('{results}', $result_campaign, $content);
        }

        echo $content;
    }

    public function pmu_recurring_campaigns_list()
    {

        global $wpdb;

        $wpdb->pmu_recurring_campaigns = $wpdb->prefix . 'pmu_recurring_campaigns';

        if ($_REQUEST['action'] == 'save') {

            $_REQUEST['image'] = explode('|', $_REQUEST['image']);
            $_REQUEST['image'] = $_REQUEST['image'][0];

            $wpdb->insert(
                $wpdb->pmu_recurring_campaigns,
                array(
                    'title' => $_REQUEST['campaigns_title'],
                    'k_id' => $_REQUEST['campaigns_kommedid'],
                ),
                array(
                    '%s', '%s', '%s', '%d',
                )
            );


            echo '<div class="updated notice">
                      <p>Changes successfully saved</p>
                </div>';

        } elseif ($_REQUEST['action'] == 'delete' && !empty($_REQUEST['id'])) {

            $wpdb->query("DELETE FROM " . $wpdb->pmu_recurring_campaigns .
                " WHERE id = '" . $_REQUEST['id'] . "'");

        } elseif ($_REQUEST['action'] == 'update' && !empty($_REQUEST['campaign_id'])) {

            $_REQUEST['image'] = explode('|', $_REQUEST['image']);
            $_REQUEST['image'] = $_REQUEST['image'][0];

            $wpdb->query("
                    UPDATE " . $wpdb->prefix . "pmu_campaigns
                    SET title = '" . $_REQUEST['campaigns_title'] . "',
                    k_id = '" . $_REQUEST['campaigns_kommedid'] . "',
                    WHERE id = " . $_REQUEST['campaign_id'] . "
                    ");

        }


        if ($_REQUEST['action'] == 'add_new' || $_REQUEST['action'] == 'edit') {
            $form_action = 'save';
            if (!empty($_REQUEST['id'])) {
                $campaign_content = $wpdb->get_row("SELECT * FROM " . $wpdb->pmu_recurring_campaigns . " WHERE id = " . $_REQUEST['id']);
                $form_action = 'update';
                $image_url = wp_get_attachment_image_src($campaign_content->image_id);
                $top_image_url = wp_get_attachment_image_src($campaign_content->top_image_id, 'pmu-320');
                if (!empty($campaign_content->image_id)) {
                    $image_class = 'with-img';
                }
            }

            $content = '
           <div class="wrap">
           <h1>Skapa nytt Månadsgivare gåvoändamål</h1>
           <form class="campaignslist" method="post" action="admin.php?page=recurring_campaigns_list&action=' . $form_action . '">
                <p>
                    <input placeholder="Title" type="text" name="campaigns_title" size="30"
                           value="' . $campaign_content->title . '" id="title" ></p>
                <p>
                    <input placeholder="Kommed id" type="text" name="campaigns_kommedid" size="30"
                           value="' . $campaign_content->k_id . '" id="title" ></p>
                <input type="hidden" name="campaign_id" value="' . $campaign_content->id . '">
                <input type="submit" class="button button-primary button-large" value="Save">
           </form>
           </div>';

        } else {
            $content = '
           <div class="wrap">
           <h1>Månadsgivare gåvoändamål <a href="admin.php?page=recurring_campaigns_list&action=add_new" class="page-title-action">Skapa nytt</a></h1>
               <table class="wp-list-table widefat fixed striped posts">
                   <thead>
                        <th>Title</th>
                        <th>Kommed id</th>
                        <th>Action</th>
                   </thead>
                   <tbody>
                        {results}
                   </tbody>
                   <tfoot></tfoot>
               </table>
           </div>';

            $campaigns = $wpdb->get_results("SELECT * FROM " . $wpdb->pmu_recurring_campaigns . " ORDER BY `order`");

            $result_campaign = '';

            foreach ($campaigns as $campaign) {
                $img_thumb = wp_get_attachment_image_src($campaign->image_id, $size = 'thumbnail');
                $result_campaign .= '<tr>
                    <td>' . $campaign->title . '</td>
                    <td>' . $campaign->k_id . '</td>
                    <td>
                        <a href="admin.php?page=recurring_campaigns_list&action=edit&id=' . $campaign->id . '">Edit</a></br>
                        <a href="admin.php?page=recurring_campaigns_list&action=delete&id=' . $campaign->id . '">Delete</a>
                    </td>
                </tr>';
            }
            $content = str_replace('{results}', $result_campaign, $content);
        }

        echo $content;
    }

    public function pmu_donation_settings_page()
    {
        $content = <<<HTML
<h1>{title}</h1>
<div class="images">
    <ul>
        {images}
    </ul>
</div>
<div class="actions">
    <button class="button button-primary button-large save">{save}</button>
</div>
HTML;

        $images_content = '';
        $donation_images = unserialize(get_option('donation_images'));

        $images = !empty($donation_images['images']) ? $donation_images['images'] : [];

        for ($i = 0; $i < 6; $i++) {
            $url = '';
            if (!empty($images[$i])) {
                $img_data = explode('|', $images[$i]);
                $url = $img_data[1];
            }

            $images_content .= '<li>
            <input type="hidden" name="images[]" value="' . (!empty($images[$i]) ? $images[$i] : '') . '">
            <a href="#" class="media-button' . (!empty($url) ? ' with-img' : '') . '"><img src="' . $url . '"></a>
        </li>';
        }

        $replaces = array(
            '{title}' => __('PMU Donation Form Settings', 'pmu_donation'),
            '{save}' => __('Save'),
            '{images}' => $images_content,
        );

        $content = str_replace(array_keys($replaces), array_values($replaces), $content);

        echo $content;
    }

    public static function pmu_donation_enqueue_site_styles($hook)
    {
        global $page_hook_suffix;

        $current_screen = get_current_screen();
        if ($current_screen->base != 'gavor_page_campaigns_list'
            && $current_screen->base != 'gavor_page_generate_certificate'
            && $current_screen->base != 'toplevel_page_pmu-donation') {
            return false;
        }

        wp_register_style('pmu-donation-css-admin', plugins_url('/css/admin.css', __FILE__));
        wp_enqueue_style('pmu-donation-css-admin');
    }

    public static function pmu_donation_enqueue_site_scripts($hook)
    {
        global $page_hook_suffix;

        /* Link our already registered script to a page */
        $current_screen = get_current_screen();

        if ($current_screen->base != 'gavor_page_campaigns_list'
            && $current_screen->base != 'gavor_page_generate_certificate'
            && $current_screen->base != 'toplevel_page_pmu-donation') {
            return false;
        }

        wp_register_script('pmu-donation-js-admin', plugins_url('/js/admin.js', __FILE__), [], false, true);
        wp_enqueue_media();
        wp_enqueue_script('pmu-donation-js-admin');

        if ($current_screen->base == 'gavor_page_generate_certificate') {
            wp_add_inline_script('pmu-donation-js-admin', "var security_key = '" . self::$security_key . "';", 'before');
        }
    }

    public static function pmu_recurring_prepare_email($order_info, $campaign_info)
    {
        if ($order_info->donation_type == 5 && $order_info->sendOption == 'send') {
            $message = get_option( 'woocommerce_recurring_message_1' );
        } else {
            $message = get_option( 'woocommerce_recurring_message_2' );
        }

        if ($order_info->sendOption == 'send') {
            $send_value = 'Din beställning skickas inom 3-4 arbetsdagar.';
        } else {
            $send_value = 'Ditt blankett bifogas här som fil <a href="http://'
                . $_SERVER['HTTP_HOST'] . '/certificate2/?code='
                . md5($order_info->id) . '" style="color:#ca2f38">PMU_D' . $order_info->id . dechex($order_info->id) . '.pdf</a>';
        }

        $message = str_replace('(sendorprint)', $send_value, $message);
        return $message;
    }

    public static function pmu_donation_prepare_email($order_info, $campaign_info)
    {
        if (empty($order_info->pdf_url)) {
            $message = get_option( 'woocommerce_donation_message_1' );
        } else {
            $message = get_option( 'woocommerce_donation_message_2' );
        }

        $message = str_replace('(Amount)', $order_info->amount, $message);
        $message = str_replace('(Reference number)', $order_info->id, $message);
        $message = str_replace('(what you are giving to)', $campaign_info->title, $message);

        if ($order_info->sendOption == 'send') {
            $send_value = 'Din beställning skickas inom 3-4 arbetsdagar.';
        } else {
            $send_value = 'Ditt gåvobevis bifogas här som fil <a href="http://'
                . $_SERVER['HTTP_HOST'] . '/certificate/?code='
                . base64_encode($order_info->id) . '&option=donation" style="color:#ca2f38">Certifikat</a>';
        }

        $message = str_replace('(sendorprint)', $send_value, $message);
        return $message;
    }

    public static function pmu_send_admin_email($mailer, $order_info, $campaign_info)
    {
        $send_to_additional_info_html = <<<HTML

------------------------------
Adress den ska skickas till
------------------------------
{fields}

------------------------------
HTML;

        $message_body = <<<HTML
<div class="fattigdom">                        
------------------------------ 
KVITTO 
------------------------------
{fields}

------------------------------ 
Summa:    {amount} SEK
{send_to_additional_info}
</div>
HTML;
        $fields = [
            'id' => 'ID',
            'full_name' => 'Namn',
            'date' => 'Datum',
            'company' => 'Företag',
            'organisation_number' => 'Organisationsnummer',
            'contact' => 'Kontaktperson',
            'email' => 'E-postadress',
            'phone' => 'Telefon',
            'street' => 'Adress',
            'zipcode' => 'Postnummer',
            'city' => 'Stad',
//            'personnumber' => 'Personnummer',
            'bankname' => 'Bankens namn',
            'clearingnumber' => 'Clearingnummer',
            'personaccount' => 'Bankkonto/Personkonto',
        ];

        if ($order_info->donation_type == 5) {
	        $fields['bank_id'] = 'Alternativ för medgivande';

	        $order_info->bank_id = 'Jag skriver ut själv';
            if ($order_info->sendOption == 'assently') {
	            $order_info->bank_id = 'Signera direkt med bankID';
            } elseif ($order_info->sendOption == 'send') {
	            $order_info->bank_id = 'Skicka blankett om autogiromedgivande hem till mig';
            }
        }

        $fields2 = [
            'name_gift' => 'Namn',
            'street_gift' => 'Adress',
            'zipcode_gift' => 'Postnummer',
            'city_gift' => 'Stad',
            'arrivaldate' => $order_info->donation_type == 2 ? 'Arrival date' : 'Begravningsdatum',
        ];

        if (in_array($order_info->donation_type, [2, 3])) {
            $fields['leverans'] = 'Leverans';
        }

        $fieldsStr = "";
        foreach ($fields as $fieldName => $fieldTitle) {
            if ($fieldName == 'full_name' && !empty($order_info->firstname)) {
                $order_info->{$fieldName} = "{$order_info->firstname} {$order_info->lastname}";
            }

            if ($fieldName == 'leverans') {
                $order_info->{$fieldName} = 'Vill skriva ut själv';
                if ($order_info->sendOption == 'send') {
                    $order_info->{$fieldName} = 'Vill få skickat';
                }
            }

            if (!empty($order_info->{$fieldName})) {
                $fieldsStr .= $fieldTitle . ": " . $order_info->{$fieldName} . "<br>";
            }
        }


        if (in_array($order_info->donation_type, [2, 3]) && $order_info->sendOption == 'send') {
            $additionalFieldsStr = '';

            if ($order_info->donation_type == 3) {
                $fields2 = array_merge(array(
                    'funeral_name' => 'Den avlidnes namn',
                ), $fields2);

                $fields2['name_gift'] = 'Namn/Begravningsbyrå';
            }

            foreach ($fields2 as $fieldName => $fieldTitle) {
                if (!empty($order_info->{$fieldName})) {
                    $additionalFieldsStr .= $fieldTitle . ": " . $order_info->{$fieldName} . "<br>";
                } elseif ($fieldName == 'funeral_name') {
                    $additionalFieldsStr .= $fieldTitle . ": " . (explode('|', $order_info->pdf_headline)[1]) . "<br>";
                }
            }

            $send_to_additional_info_html = str_replace('{fields}', $additionalFieldsStr, $send_to_additional_info_html);
        } elseif ($order_info->donation_type == 3) {
            $additionalFieldsStr = '';

            $fields2 = array(
                'funeral_name' => 'Den avlidnes namn',
            );

            foreach ($fields2 as $fieldName => $fieldTitle) {
                if (!empty($order_info->{$fieldName})) {
                    $additionalFieldsStr .= $fieldTitle . ": " . $order_info->{$fieldName} . "<br>";
                } elseif ($fieldName == 'funeral_name') {
                    $additionalFieldsStr .= $fieldTitle . ": " . (explode('|', $order_info->pdf_headline)[1]) . "<br>";
                }
            }

            $send_to_additional_info_html = str_replace('{fields}', $additionalFieldsStr, $send_to_additional_info_html);
        } else {
            $send_to_additional_info_html = '';
        }



        $replaces = [
            '{fields}' => $fieldsStr,
            '{amount}' => $order_info->amount,
            '{send_to_additional_info}' => $send_to_additional_info_html,
        ];

        if (in_array($order_info->donation_type, [2,3,5])) {
            $message_body .= '<b>PDF:</b>
                                    <a href="https://' . $_SERVER['HTTP_HOST'] . '/certificate' . ($order_info->donation_type == 5 ? '2' : '') . '/?code='
                . (in_array($order_info->donation_type, [2,3]) ? base64_encode($order_info->id) . '&option=donation' : md5($order_info->id))
                . '">PMU_D' . $order_info->selectedCampaign . '' . dechex($order_info->id) . '.pdf</a>';
        }

        $message_body = str_replace(array_keys($replaces), array_values($replaces), $message_body);

//        if ($order_info->sendOption == 'nosend' || empty($order_info->sendOption)) {
//            $subject = '{name} - vill skriva ut själv';
//        } else {
//            $subject = '{name} - vill få skickat';
//        }

        $subject = '{name} - ID {donation_id}';

        switch ($order_info->donation_type) {
            case 5:
                $name = 'Ny månadsgivare';
                break;
            case 3:
                $name = 'Ny minnesgåva';
                break;
            case 2:
                $name = 'Ny hyllningsgåva';
                break;
            default:
                $name = 'Engångsgåva';
                break;
        }

        $replaces = [
            '{name}' => $name,
            '{donation_id}' => $order_info->id,
        ];

        $subject = str_replace(array_keys($replaces), array_values($replaces), $subject);

        $message = $mailer->wrap_message($subject, $message_body);
        $mailer->send( 'wendy.eklund@pmu.se', $subject, $message );
        $mailer->send( 'per.asp@pmu.se', $subject, $message );
        $mailer->send( 'ludmila.kazakova@pmu.se', $subject, $message );
        $mailer->send( 'towe.mikmar@pmu.se', $subject, $message );
//        $mailer->send( 'slavic@gofervent.com', $subject, $message );
    }

    public static function wc_ajax_save_donation_img()
    {
        parse_str($_POST['data'], $data);
        update_option('donation_images', serialize($data));
        update_option('donation_update_notice', '1');
        die();
    }

    public static function donation_update_notice()
    {
        ?>
        <div class="updated notice">
            <p><?php _e('Changes successfully saved!', 'pmu_donation'); ?></p>
        </div>
        <?php
    }

    public static function get_images()
    {
        $donation_images = unserialize(get_option('donation_images'));
        $images = !empty($donation_images['images']) ? $donation_images['images'] : [];

        $images = array_map(function ($val) {
            $data = explode('|', $val);

            if (count($data) == 2) {
                return $data[1];
            }

            return $val;
        }, $images);

        return $images;
    }

    public static function send_kommed($order_info, $campaign_info)
    {
        $target_from = !empty($order_info->firstname) ? $order_info->firstname : 'anonymous';
        $target_from .= ' ' . !empty($order_info->lastname) ? $order_info->lastname : 'anonymous';

        $date = explode('/', $order_info->arrivaldate);

        if (count($date) == 3) {
            $date = $date[2] . '-' . $date[0] . '-' . $date[1];
        } else {
            $date = '';
        }

        $data = array(
            'firstname' => !empty($order_info->firstname) ? $order_info->firstname : 'anonymous',
            'lastname' => !empty($order_info->lastname) ? $order_info->lastname : 'anonymous',
            'address' => $order_info->street,
            'zip' => $order_info->zipcode,
            'city' => $order_info->city,
            'country_id' => 46,
            'social_id' => ($order_info->donation_type == 5 ? str_replace('-', '', $order_info->personnumber) : $order_info->organisation_number),
            'company' => $order_info->company,
            'email' => $order_info->email,
            'mobile' => $order_info->phone,
            'amount' => $order_info->amount,
            'pledge_target' => $campaign_info->k_id,
//            'pledge_target' => 1105,
            'payment_id1' => ($order_info->donation_type == 5 ? $order_info->clearingnumber : $order_info->id),
            'payment_id2' => ($order_info->donation_type == 5 ? $order_info->personaccount : $order_info->id),
            'paid_with' => ($order_info->donation_type == 5 ? -2 : 1),
            'type' => '',
            'sendto' => 0,
            'date' => $date,
            'image_id' => self::get_kommed_image_id($order_info->pdf_url),
            'target_from' => $target_from,
        );

        if($order_info->paymentType == 'PMU_DONATION_directbank_v2'){
            $data['paid_with'] = 2;
        }

        // Autogiro, signed with e-leg
        // Use same approach as in 'on off donation' but set paid_with to -5
        if($order_info->donation_type == 5 && $order_info->sendOption == 'assently') {
            $data['paid_with'] = -5;
        } elseif ($order_info->donation_type == 5) {
            // Autogiro, when the donor wants a form sent on paper
            // Use same approach as in 'on off donation' but set paid_with to -2
            $data['paid_with'] = -2;
        }

        switch ((int) $order_info->donation_type) {
            case 1: // Regular (without certificate)
                $obj = new RegularWithoutCertParams();
                break;
            case 2: // Regular (with gift certificate)
                $data['type'] = 2;
                if ($order_info->sendOption == 'send') {
                    $data['sendto'] = implode(', ', [
                        $order_info->name_gift,
                        $order_info->street_gift,
                        $order_info->zipcode_gift,
                        $order_info->city_gift
                    ]);
                }

                $data['target_name'] = $order_info->pdf_headline;

                $obj = new RegularWithGiftCertParams();
                break;
            case 3: // Regular (with funeral certificate)
                $data['type'] = 1;
                if ($order_info->sendOption == 'send') {
                    $data['sendto'] = implode(', ', [
                        $order_info->name_gift,
                        $order_info->street_gift,
                        $order_info->zipcode_gift,
                        $order_info->city_gift
                    ]);
                }

                $target_name = explode('|', $order_info->pdf_headline);

                $data['target_name'] = $target_name[1];
                $data['target_text'] = $order_info->pdf_greeting;
                $obj = new RegularWithFuneralCertParams();
                break;
            case 4: // Business (without certificate)
                $data['firstname'] = $order_info->contact;
                $data['lastname'] =  $order_info->contact;
                $obj = new BusinessParams();
                break;
            case 5: // Business (without certificate)
                $obj = new RecurringParams();
                break;
        }


        $obj->initParams($data);
        $res = Kommed::getInstance()->addPaymentV2($obj);

        if ($order_info->sendOption == 'send' && $order_info->donation_type != 5) {
            $data['amount'] = 30;
            $data['pledge_target'] = 2752;

            $obj->initParams($data);
            $res = Kommed::getInstance()->addPaymentV2($obj);
        }

    }
}

add_action('wp_head', 'pmu_donation_wp_loaded');
function pmu_donation_wp_loaded() {
	if ( strpos( $_SERVER['REQUEST_URI'], 'gegava/dibs_callback.php' ) ) {
		PMU_Donation_Form::dibs_callback();
	}
}

add_shortcode('pmu_donation', ['PMU_Donation_Form', 'render_donation_form']);

add_action('admin_menu', ['PMU_Donation_Form', 'add_pmu_donation_menu_items']);

add_action('admin_enqueue_scripts', ['PMU_Donation_Form', 'pmu_donation_enqueue_site_styles']);
add_action('admin_enqueue_scripts', ['PMU_Donation_Form', 'pmu_donation_enqueue_site_scripts']);

add_action('wp_ajax_save_donation_img', ['PMU_Donation_Form', 'wc_ajax_save_donation_img']);
add_action('wp_ajax_save_donation_img', ['PMU_Donation_Form', 'wc_ajax_save_donation_img']);

add_action('wp_ajax_update_campaigns_order', ['PMU_Donation_Form', 'update_campaigns_order']);


if (get_option('donation_update_notice')) {
    delete_option('donation_update_notice');
    add_action('admin_notices', ['PMU_Donation_Form', 'donation_update_notice']);
}


add_action('rest_api_init', 'dt_register_api_hooks');
function dt_register_api_hooks()
{

    $namespace = 'process-donation';

    register_rest_route($namespace, '/neworder/', array(
        'methods' => 'POST',
        'callback' => 'save_donation',
    ));

    register_rest_route($namespace, '/get-address/', array(
        'methods' => 'POST',
        'callback' => 'get_address',
    ));
}

function get_address()
{
    include_once("spar/spar.php"); die();
}

function save_donation()
{
    $params = json_decode(file_get_contents('php://input'), true);

    global $wpdb;

    function addQuotes($str){
        return "'$str'";
    }

    $params['company'] = !empty($params['company']) ? addQuotes($params['company']) : 'NULL';
    $params['organisation_number'] = !empty($params['organisation_number']) ? addQuotes($params['organisation_number']) : 'NULL';
    $params['contact'] = !empty($params['contact']) ? addQuotes($params['contact']) : 'NULL';
    $params['phone'] = !empty($params['phone']) ? addQuotes($params['phone']) : 'NULL';
    $params['email'] = !empty($params['email']) ? addQuotes($params['email']) : 'NULL';
    $params['deceaseds_name'] = !empty($params['deceaseds_name']) ? addQuotes($params['deceaseds_name']) : 'NULL';
    $params['personnumber'] = !empty($params['personnumber']) ? addQuotes($params['personnumber']) : 'NULL';
    $params['bankname'] = !empty($params['bankname']) ? addQuotes($params['bankname']) : 'NULL';
    $params['clearingnumber'] = !empty($params['clearingnumber']) ? addQuotes($params['clearingnumber']) : 'NULL';
    $params['personaccount'] = !empty($params['personaccount']) ? addQuotes($params['personaccount']) : 'NULL';

    if ($params['donation_type'] == 5) {
        $params['selectedCampaign'] = $params['selectedGiverType'];
        $params['sendOption'] = $params['deliveryOption'] == 'no' ? 'nosend'
            : ( $params['deliveryOption'] == 'assently' ? 'assently' : 'send' );
    }

    $params = (object) $params;

    $params->headline = addslashes($params->headline);
    $params->greeting = addslashes($params->greeting);

    if (!empty($params->name_deceased)) {
        $params->headline .= '|' . $params->name_deceased;
    }

    $query = <<<SQL
INSERT INTO {$wpdb->prefix}pmu_entries (
    amount, date, paymentType, firstname,
    lastname, company, organisation_number, contact,
    email, phone, street, zipcode,
    city, pdf_url, pdf_headline, 
    pdf_greeting, sendOption, name_gift, street_gift,
    zipcode_gift, city_gift, deceaseds_name,
    arrivaldate, selectedCampaign, donation_type,
    personnumber, bankname, clearingnumber, personaccount)
VALUES (
    $params->amount, NOW(),'$params->paymentType','$params->firstname',
    '$params->lastname',$params->company,$params->organisation_number,$params->contact,
    $params->email,$params->phone,'$params->street','$params->zipcode',
    '$params->city','$params->backgroundUrl','$params->headline',
    '$params->greeting','$params->sendOption','$params->name_gift','$params->street_gift',
    '$params->zipcode_gift','$params->city_gift', $params->deceaseds_name,
    '$params->arrivaldate','$params->selectedCampaign',$params->donation_type,
     $params->personnumber, $params->bankname, $params->clearingnumber, $params->personaccount)
SQL;

    $wpdb->query($query);

    ob_clean();

    if ($params->donation_type == 5) {
        $order_info = $wpdb->get_row("SELECT * FROM " . $wpdb->prefix . "pmu_entries
            WHERE id = " . $wpdb->insert_id
        );

        // If selected assently
        if ($order_info->sendOption == 'assently') {
            // Create assently document
            $document_id = createAssentlyDocument($order_info, '/certificate2/?code=' . md5($wpdb->insert_id));

            // Add assently document id to current row
            $wpdb->query("UPDATE " . $wpdb->prefix . "pmu_entries
                SET assently_doc_id = '" . $document_id . "'
                WHERE id = " . $wpdb->insert_id
            );

            // Redirect to sign document link
            return array("redirect_to" => get_signed_page_url($document_id));
        } else {
            return array("code" => md5($wpdb->insert_id));
        }

    }
    $response = array("database_id" => $wpdb->insert_id);

    return $response;
}

function createAssentlyDocument($params, $document_link)
{
    ini_set('display_errors', 'On');
    error_reporting(E_ALL);
    $assently = new Assently();

    $key = getenv('ASSENTLY_KEY');
    $secret = getenv('ASSENTLY_SECRET');

    $assently->authenticate($key, $secret);

    $url = 'https://' . $_SERVER['HTTP_HOST'] . '/manadsgivare/';
    $agreement_id = date('Ymd') . '-' . md5(time());

    $file_name = 'PMU_D' . $params->id . dechex($params->id) . '.pdf';
    $tmp_file = $_SERVER['DOCUMENT_ROOT'] . '/wp-content/uploads/' . $file_name;
    file_get_contents('https://' . $_SERVER['HTTP_HOST'] . $document_link . '&save=1');

    $data = [
        'name' => 'Autogiromedgivande',
        'NameAlias' => 'agreement-' . $agreement_id,
        'AllowedSignatureTypes' => [
            'electronicid',
            'touch',
            'sms'
        ],
        'CancelUrl' => $url . '?assently_status=cancel',
        'ContinueUrl' => $url . '?assently_status=success',
        'ContinueName' => 'Return to pmu.se',
        'ContinueAuto' => true,
        'EventCallback' => [
            'Events' => [
                'signatureadded',
//                'approvalrequested'
            ],
            'Url' => $url . '?assently_callback=1'
        ],
        'Documents' => [
            $assently->document()->create($tmp_file)
        ],
        "Parties" => [
            $assently->party()->create([
                'Name'          => $params->firstname . ' ' . $params->lastname,
//                'EmailAddress'  => $params->email,
                'AnyoneCanSign' => false
            ])
        ],
        'IsEditable' => true
    ];

    $assently_document = $assently->_case()->create($data)->send()->remind();

    unlink($tmp_file);

    return $assently_document->id;
}

function get_signed_page_url($document_id) {
    $assently = new Assently();

    $key = getenv('ASSENTLY_KEY');
    $secret = getenv('ASSENTLY_SECRET');

    $assently->authenticate($key, $secret);

    return $assently->_case()->find($document_id)->case->Parties[0]->PartyUrl;
}